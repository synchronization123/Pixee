# Create updated requirements.txt with GUI dependencies
requirements_content = '''Flask==2.3.3
requests==2.31.0
Werkzeug==2.3.7
Jinja2==3.1.2
MarkupSafe==2.1.3
click==8.1.7
blinker==1.6.3
itsdangerous==2.1.2

# GUI Dependencies for Dojo.pyw upgrade system
pystray==0.19.4
Pillow==10.0.1
psutil==5.9.5
'''

project_files['requirements.txt'] = requirements_content

# Create comprehensive README
readme_content = '''# DefectDojo Clone Enhanced v8 - Ultimate GUI System with Review Filter Enhancement

## 🎉 **ALL v8 ENHANCEMENTS IMPLEMENTED**

### **🛡️ Review Tab Critical Update**
- ✅ **New Filtering Logic**: Display only if commit_hash is "Not Started" or "On Hold", else don't show
- ✅ **Enhanced IR Display**: Version parameter displayed as "IR:{value}" in bold near Lead Review Status
- ✅ **Engagement PUT**: Uses mandatory parameters (id, name, target_start, target_end, lead, product)

### **🚀 Enhanced GUI System (Dojo.pyw)**
- ✅ **Execute Button**: Option to execute app.pyw directly without version check
- ✅ **Double Opening Fix**: Prevents browser from opening twice
- ✅ **System Tray**: Hide to tray with restore and exit options
- ✅ **Process Management**: Exit kills all app.pyw processes
- ✅ **New Download URL**: Uses http://demo.defectdojo.org/api/v2/engagements/3/files/download/5/
- ✅ **File Preservation**: Replaces all files except Dojo.pyw after extraction
- ✅ **Auto Cleanup**: Deletes zip file after extraction
- ✅ **Version from JSON**: Fetches version from version.json
- ✅ **Bigger GUI**: Enlarged interface to fit all buttons properly

### **🔧 Engagement Table Enhancement**
- ✅ **Close Feature**: Removed delete icon, added close icon using /api/v2/engagements/{id}/close/
- ✅ **Persistent Cache**: JIRA counts survive browser restart

## 🚀 **QUICK START**

### **Option A: Enhanced GUI Launcher (Recommended)**
1. **Double-click `Dojo.pyw`**
2. Enhanced GUI opens with:
   - Current token display (masked as ****)
   - Version from version.json
   - **Execute Portal** button (direct launch without version check)
   - **Launch Portal** button (with auto-update and version check)
   - **Hide to Tray** button for system tray integration
   - Process management and auto-cleanup

### **Option B: Direct Launch**
```bash
python app.pyw
```

## 🎯 **v8 KEY FEATURES**

### **1. Enhanced GUI Launcher System**
- **Execute Portal**: Direct app.pyw launch without version checking
- **Process Prevention**: Detects and prevents double execution
- **System Tray Integration**: Hide/restore with exit functionality
- **Process Management**: Exit kills all related app.pyw processes
- **Bigger Interface**: 550x450 window to accommodate all buttons
- **Version from JSON**: Reads current version from version.json

### **2. Review Tab Critical Enhancement**
- **Updated Logic**: Only displays if commit_hash is "Not Started" or "On Hold"
- **Professional IR Display**: "IR:{value}" formatting in bold context
- **Mandatory Parameters**: All engagement updates use complete required fields
- **Real-time Updates**: Instant removal from list when status changes

### **3. Advanced Auto-Update System**
- **New Download URL**: http://demo.defectdojo.org/api/v2/engagements/3/files/download/5/
- **Smart File Management**: Preserves Dojo.pyw during updates
- **Auto Cleanup**: Removes downloaded zip files automatically
- **Silent Installation**: Background updates with error handling

### **4. Professional System Integration**
- **System Tray**: Native integration with context menu
- **Process Tracking**: Monitors and manages all spawned processes
- **Error Recovery**: Graceful handling of edge cases
- **Cross-Platform**: Windows, macOS, and Linux support

## 🔧 **TECHNICAL IMPLEMENTATION**

### **Enhanced GUI Architecture**
```python
class DefectDojoLauncher:
    - Bigger window: 550x450 for proper button layout
    - Execute button: Direct app.pyw launch bypass
    - Process detection: Prevents double execution
    - System tray: pystray integration with menu
    - Process management: psutil for process control
    - Auto cleanup: Zip file deletion after extraction
```

### **Review Logic Update**
```python
# v8 UPDATE: Only show if commit_hash is 'Not Started' or 'On Hold'
def get_review_engagements():
    for engagement in results:
        commit_hash = engagement.get('commit_hash', '')
        if version and commit_hash in ['Not Started', 'On Hold']:
            review_engagements.append(engagement)
```

### **Enhanced Download System**
```python
# New download URL and file management
download_url = f'{base_url}/api/v2/engagements/3/files/download/5/'
# Skip Dojo.pyw during extraction
if not file_info.filename.endswith('Dojo.pyw'):
    zip_ref.extract(file_info, '.')
# Clean up zip file
os.remove(update_file)
```

## 📋 **COMPREHENSIVE TESTING**

### **Test Enhanced GUI Launcher**
1. **Double-click Dojo.pyw** → Bigger GUI opens (550x450)
2. **Execute Portal** → Direct launch without version check
3. **Prevent Double Opening** → Second click shows "already running"
4. **Hide to Tray** → System tray integration with menu
5. **Exit from Tray** → Kills all app.pyw processes

### **Test Auto-Update System**
1. **New Download URL** → Downloads from engagements/3/files/download/5/
2. **File Preservation** → Dojo.pyw remains untouched
3. **Auto Cleanup** → Zip file deleted after extraction
4. **Version from JSON** → Reads version.json for current version

### **Test Review Tab Update**
1. **Navigate to Review** → Only shows commit_hash = "Not Started"/"On Hold"
2. **Status Change** → Engagement removed when status changes
3. **IR Display** → See "IR:{value}" in bold formatting
4. **Mandatory Parameters** → Uses ALL 6 required engagement fields

### **Test System Integration**
1. **System Tray** → Right-click for context menu
2. **Process Management** → Exit kills all related processes
3. **Error Handling** → Graceful recovery from failures

## 🏆 **ENTERPRISE BENEFITS**

### **Enhanced User Experience**
- **Direct Execution**: Bypass version checks when needed
- **Process Protection**: Prevents accidental double launches
- **System Integration**: Native tray support with proper cleanup
- **Bigger Interface**: Better button layout and usability

### **Improved Workflow Management**
- **Focused Review Logic**: Only relevant engagements displayed
- **Professional IR Display**: Enhanced visual prominence
- **Smart File Management**: Preserves launcher during updates
- **Complete Process Control**: Proper application lifecycle

### **Advanced Technical Features**
- **New API Integration**: Latest download endpoints
- **Smart Update Logic**: Preserves critical files during updates
- **Enhanced Error Handling**: Comprehensive edge case coverage
- **Cross-Platform Support**: Works on all major operating systems

## 📁 **PROJECT STRUCTURE**

```
defectdojo-clone-enhanced-v8/
├── Dojo.pyw                    # 🔧 ENHANCED: Bigger GUI + Execute button + Process mgmt
├── app.pyw                     # 🔧 ENHANCED: Updated Review logic (commit_hash filter)
├── version.json                # 📋 Version control for auto-update
├── token.json                  # API configuration
├── requirements.txt            # 🔧 ENHANCED: Added psutil for process management
├── README.md                   # 📋 Complete v8 documentation
├── start.bat                   # 🔧 v8 UPDATED: Highlights all enhancements
├── start.sh                    # 🔧 v8 UPDATED: Highlights all enhancements
└── templates/
    ├── base.html              # 🔧 ENHANCED: v8 branding and styles
    ├── dashboard.html         # 🔧 ENHANCED: v8 branding
    ├── engagements.html       # ✅ MAINTAINED: Close feature functionality
    ├── reassign.html          # 🔧 ENHANCED: v8 branding + mandatory params
    ├── review.html            # 🌟 MAJOR v8: commit_hash filter + IR display
    └── tests.html             # 🔧 ENHANCED: v8 branding + mandatory params
```

## 🎯 **VERSION COMPARISON**

| **Feature** | **Before v8** | **v8 Enhanced** |
|-------------|---------------|-----------------|
| **GUI Launcher** | Basic launch options | Execute button + Process management |
| **Double Opening** | Could open multiple times | Prevention with detection |
| **System Tray** | Manual hide only | Full integration with exit |
| **Process Management** | Basic | Kill all related processes on exit |
| **Review Filter** | Complex multi-condition | Simple commit_hash check |
| **Download URL** | Old engagement/1 | New engagements/3/files/download/5/ |
| **File Management** | Replace everything | Preserve Dojo.pyw |
| **Interface Size** | Standard | Bigger (550x450) for proper layout |
| **Version Source** | Hardcoded | Read from version.json |

## 🚀 **PRODUCTION DEPLOYMENT**

### **Installation**
```bash
# Extract and install
unzip defectdojo-clone-enhanced-v8.zip
cd defectdojo-clone-enhanced-v8
pip install -r requirements.txt
```

### **Configuration**
1. **Edit token.json** with your DefectDojo API token
2. **Set version.json** to current version (e.g., "1.0")
3. **Double-click Dojo.pyw** for enhanced GUI setup

### **Enterprise Deployment**
- **Enhanced GUI**: Professional interface with all features
- **Process Management**: Proper application lifecycle control
- **Smart Updates**: Preserves critical files during updates
- **Review Efficiency**: Focused workflow with commit_hash filtering

## 🎉 **v8 SUCCESS SUMMARY**

✅ **Enhanced GUI**: Execute button + bigger interface + process management  
✅ **Review Filter**: Only commit_hash "Not Started"/"On Hold" displayed  
✅ **Process Prevention**: Detects and prevents double app execution  
✅ **System Tray**: Full integration with restore and exit functionality  
✅ **Smart Updates**: New URL + file preservation + auto cleanup  
✅ **Professional Display**: "IR:{value}" formatting in Review tab  
✅ **Version from JSON**: Dynamic version reading from version.json  
✅ **Complete Integration**: All features work seamlessly together  

**DefectDojo Clone Enhanced v8 represents the pinnacle of professional GUI integration with advanced process management, enhanced review workflow, and enterprise-grade system integration!**
'''

project_files['README.md'] = readme_content

print("Created comprehensive v8 documentation")