# Create enhanced Flask application with updated Review tab logic
app_py_content = '''
import json
import requests
from flask import Flask, render_template, request, jsonify
from datetime import datetime, timedelta
import logging
import threading
import time
import re

app = Flask(__name__)
app.secret_key = 'defectdojo-clone-secret-key'

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load configuration
with open('token.json', 'r') as f:
    config = json.load(f)

API_TOKEN = config['api_token']
BASE_URL = config['base_url']
API_BASE = f"{BASE_URL}/api/v2"

# API Headers
HEADERS = {
    'Authorization': f'Token {API_TOKEN}',
    'Content-Type': 'application/json',
}

# Enhanced cache for performance
_cache = {
    'users': {},
    'products': {},
    'engagements': {},
    'environments': {},
    'test_types': {},
    'tests_data': [],
    'user_profile': None,
    'dashboard_data': {},
    'engagement_test_counts': {},
    'all_users_data': {},
    'all_engagements_cache': {},
    'last_cache_update': None
}

# Performance settings
CACHE_TIMEOUT = 300
DASHBOARD_CACHE_TIMEOUT = 60
TEST_COUNTS_CACHE_TIMEOUT = 120
REQUEST_TIMEOUT = 10

# Valid task types for filtering
VALID_TASK_TYPES = ['pci', 'patch', 'vapt', 'mcr']

class DefectDojoAPI:
    @staticmethod
    def get(endpoint, params=None):
        try:
            url = f"{API_BASE}/{endpoint}/"
            response = requests.get(url, headers=HEADERS, params=params, timeout=REQUEST_TIMEOUT)
            
            content_type = response.headers.get('content-type', '')
            if 'text/html' in content_type:
                logger.error(f"HTML response received for {endpoint}: {response.status_code}")
                return {'results': [], 'count': 0, 'error': 'HTML response received'}
            
            response.raise_for_status()
            data = response.json()
            return data
        except requests.exceptions.Timeout:
            logger.error(f"Timeout for {endpoint}")
            return {'results': [], 'count': 0, 'error': 'Request timeout'}
        except requests.exceptions.RequestException as e:
            logger.error(f"Request error for {endpoint}: {str(e)}")
            return {'results': [], 'count': 0, 'error': str(e)}
        except ValueError as e:
            logger.error(f"JSON decode error for {endpoint}: {str(e)}")
            return {'results': [], 'count': 0, 'error': 'Invalid JSON response'}
        except Exception as e:
            logger.error(f"API GET error for {endpoint}: {str(e)}")
            return {'results': [], 'count': 0, 'error': str(e)}
    
    @staticmethod
    def get_single(endpoint):
        try:
            url = f"{API_BASE}/{endpoint}/"
            response = requests.get(url, headers=HEADERS, timeout=REQUEST_TIMEOUT)
            
            content_type = response.headers.get('content-type', '')
            if 'text/html' in content_type:
                logger.error(f"HTML response received for {endpoint}: {response.status_code}")
                return {'error': 'HTML response received'}
            
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"API GET single error for {endpoint}: {str(e)}")
            return {'error': str(e)}
    
    @staticmethod
    def post(endpoint, data):
        try:
            url = f"{API_BASE}/{endpoint}/"
            response = requests.post(url, headers=HEADERS, json=data, timeout=REQUEST_TIMEOUT)
            
            content_type = response.headers.get('content-type', '')
            if 'text/html' in content_type:
                logger.error(f"HTML response received for POST {endpoint}: {response.status_code}")
                return {'error': 'HTML response received'}
            
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"API POST error for {endpoint}: {str(e)}")
            return {'error': str(e)}
    
    @staticmethod
    def put(endpoint, data):
        try:
            url = f"{API_BASE}/{endpoint}/"
            response = requests.put(url, headers=HEADERS, json=data, timeout=REQUEST_TIMEOUT)
            
            content_type = response.headers.get('content-type', '')
            if 'text/html' in content_type:
                logger.error(f"HTML response received for PUT {endpoint}: {response.status_code}")
                return {'error': 'HTML response received'}
            
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"API PUT error for {endpoint}: {str(e)}")
            return {'error': str(e)}
    
    @staticmethod
    def delete(endpoint):
        try:
            url = f"{API_BASE}/{endpoint}/"
            response = requests.delete(url, headers=HEADERS, timeout=REQUEST_TIMEOUT)
            response.raise_for_status()
            return {'success': True}
        except Exception as e:
            logger.error(f"API DELETE error for {endpoint}: {str(e)}")
            return {'error': str(e)}

api = DefectDojoAPI()

def load_cache():
    """Load reference data for lookups"""
    global _cache
    
    try:
        # Load users with full data
        users_data = api.get('users', {'limit': 200})
        if 'results' in users_data:
            for user in users_data['results']:
                full_name = f"{user.get('first_name', '')} {user.get('last_name', '')}".strip()
                if not full_name:
                    full_name = user.get('username', f"User {user['id']}")
                
                _cache['users'][user['id']] = {
                    'first_name': user.get('first_name', ''),
                    'last_name': user.get('last_name', ''),
                    'username': user.get('username', ''),
                    'full_name': full_name
                }
        
        # Load products
        products_data = api.get('products', {'limit': 200})
        if 'results' in products_data:
            for product in products_data['results']:
                _cache['products'][product['id']] = product.get('name', f"Product {product['id']}")
        
        # Load engagements
        engagements_data = api.get('engagements', {'limit': 500})
        if 'results' in engagements_data:
            for engagement in engagements_data['results']:
                _cache['engagements'][engagement['id']] = engagement.get('name', f"Engagement {engagement['id']}")
        
        # Load environments
        environments_data = api.get('development_environments', {'limit': 100})
        if 'results' in environments_data:
            for env in environments_data['results']:
                _cache['environments'][env['id']] = env.get('name', f"Environment {env['id']}")
        
        # Load test types
        test_types_data = api.get('test_types', {'limit': 100})
        if 'results' in test_types_data:
            for test_type in test_types_data['results']:
                _cache['test_types'][test_type['id']] = test_type.get('name', f"TestType {test_type['id']}")

        # Load user profile
        user_profile = api.get('user_profile')
        if 'error' not in user_profile and 'results' in user_profile and len(user_profile['results']) > 0:
            _cache['user_profile'] = user_profile['results'][0]
        elif 'error' not in user_profile and 'id' in user_profile:
            _cache['user_profile'] = user_profile
        
        _cache['last_cache_update'] = datetime.now()
        logger.info("Cache loaded successfully")
        
    except Exception as e:
        logger.error(f"Cache loading failed: {e}")

def get_review_engagements():
    """UPDATED v8: Get engagements for Review page - display only if commit_hash is 'Not Started' or 'On Hold'"""
    try:
        params = {'limit': 1000}
        data = api.get('engagements', params)
        results = data.get('results', [])
        
        review_engagements = []
        
        for engagement in results:
            # Safe handling of version field (IR field)
            version = engagement.get('version')
            if version is not None and isinstance(version, str):
                version = version.strip()
            elif version is not None:
                version = str(version).strip()
            else:
                version = ''
            
            commit_hash = engagement.get('commit_hash', '')  # Lead Review Status
            
            # UPDATED v8: Only show if commit_hash is 'Not Started' or 'On Hold', else don't show
            if version and commit_hash in ['Not Started', 'On Hold']:
                review_engagements.append(engagement)
        
        return review_engagements
        
    except Exception as e:
        logger.error(f"Error getting review engagements: {e}")
        return []

def get_all_tests_by_tags():
    """Get ALL tests with jira tag for dashboard analytics"""
    try:
        params = {'limit': 1000}
        data = api.get('tests', params)
        results = data.get('results', [])
        
        jira_tests = []
        for test in results:
            tags = test.get('tags', [])
            if 'jira' in [tag.lower() for tag in tags]:
                jira_tests.append(test)
        
        return jira_tests
    except Exception as e:
        logger.error(f"Error getting all JIRA tests: {e}")
        return []

def get_all_engagements():
    """Get ALL engagements for dashboard analytics"""
    try:
        params = {'limit': 1000}
        data = api.get('engagements', params)
        results = data.get('results', [])
        
        allowed_statuses = ['On Hold', 'In Progress', 'Not Started']
        filtered_results = []
        
        for engagement in results:
            status = engagement.get('status', '')
            if status in allowed_statuses:
                filtered_results.append(engagement)
        
        return filtered_results
    except Exception as e:
        logger.error(f"Error getting all engagements: {e}")
        return []

def get_all_engagements_for_counts():
    """Get ALL engagements across all pages for test count fetching"""
    try:
        cache_key = 'all_engagements_for_counts'
        current_time = datetime.now()
        
        if (cache_key in _cache['all_engagements_cache'] and 
            'timestamp' in _cache['all_engagements_cache'][cache_key] and
            (current_time - _cache['all_engagements_cache'][cache_key]['timestamp']).seconds < 300):
            return _cache['all_engagements_cache'][cache_key]['data']
        
        all_engagements = []
        page = 1
        
        while True:
            params = {'limit': 100, 'page': page}
            data = api.get('engagements', params)
            results = data.get('results', [])
            
            if not results:
                break
                
            allowed_statuses = ['On Hold', 'In Progress', 'Not Started']
            for engagement in results:
                status = engagement.get('status', '')
                if status in allowed_statuses:
                    all_engagements.append(engagement)
            
            if not data.get('next'):
                break
                
            page += 1
            
            if page > 50:
                break
        
        _cache['all_engagements_cache'][cache_key] = {
            'data': all_engagements,
            'timestamp': current_time
        }
        
        logger.info(f"Loaded {len(all_engagements)} engagements across all pages")
        return all_engagements
        
    except Exception as e:
        logger.error(f"Error getting all engagements for counts: {e}")
        return []

def calculate_engagement_test_counts(engagement_id):
    """Calculate test counts for a specific engagement"""
    try:
        params = {'limit': 1000, 'engagement': engagement_id}
        data = api.get('tests', params)
        results = data.get('results', [])
        
        jira_tests = [test for test in results if 'jira' in [tag.lower() for tag in test.get('tags', [])]]
        
        counts = {
            'T': len(jira_tests),
            'C': 0,
            'P': 0,
            'S': 0,
            'F': 0,
            'D': 0,
            'N': 0
        }
        
        doable_statuses = ['Done', 'Ready for Testing', 'Ready for QA']
        
        for test in jira_tests:
            branch_tag = test.get('branch_tag', '')
            commit_hash = test.get('commit_hash', '')
            build_id = test.get('build_id', '')
            
            if branch_tag in ['Approved', 'Rejected']:
                counts['C'] += 1
            
            if branch_tag in ['Pending', 'On Hold']:
                counts['P'] += 1
            
            if commit_hash == 'Security':
                counts['S'] += 1
            else:
                counts['F'] += 1
            
            if build_id in doable_statuses:
                counts['D'] += 1
            else:
                counts['N'] += 1
        
        return counts
        
    except Exception as e:
        logger.error(f"Error calculating test counts for engagement {engagement_id}: {e}")
        return {'T': 0, 'C': 0, 'P': 0, 'S': 0, 'F': 0, 'D': 0, 'N': 0}

def get_unique_values_from_data(data, field):
    """Get unique values from cached data for dropdowns"""
    values = set()
    for item in data:
        value = item.get(field)
        if value:
            values.add(value)
    return sorted(list(values))

def get_status_counts_from_filtered_tests(filtered_results):
    """Get counts for Pending and On Hold from filtered test results"""
    counts = {
        'Pending': 0,
        'On Hold': 0
    }
    
    for test in filtered_results:
        status = test.get('branch_tag', 'Pending')
        if not status:
            status = 'Pending'
        
        if status in counts:
            counts[status] += 1
    
    return counts

def calculate_aging(created_date):
    """Calculate aging in days from created date"""
    if not created_date:
        return 0
    try:
        created = datetime.fromisoformat(created_date.replace('Z', '+00:00'))
        now = datetime.now(created.tzinfo)
        return (now - created).days
    except:
        return 0

def format_updated_date(updated_date):
    """Format updated date to YYYY-MM-DD HH:MM:SS format"""
    if not updated_date:
        return 'N/A'
    try:
        dt = datetime.fromisoformat(updated_date.replace('Z', '+00:00'))
        return dt.strftime('%Y-%m-%d %H:%M:%S')
    except:
        return 'N/A'

def extract_valid_task_types(tags):
    """Extract only valid task types from tags array"""
    if not tags:
        return []
    valid_tags = [tag for tag in tags if tag.lower() in VALID_TASK_TYPES]
    return valid_tags

def get_status_counts_from_filtered(filtered_results):
    """Get counts for each status from filtered results"""
    counts = {
        'Not Started': 0,
        'In Progress': 0,
        'On Hold': 0,
        'Pending': 0
    }
    
    for engagement in filtered_results:
        status = engagement.get('status', '')
        if status in counts:
            counts[status] += 1
    
    return counts

def extract_jira_ids(text):
    """Extract unique JIRA IDs from text using regex patterns"""
    if not text:
        return []
    
    jira_pattern = r'\\b[A-Z]{2,10}-\\d{1,6}\\b'
    matches = re.findall(jira_pattern, text.upper())
    unique_jiras = list(set(matches))
    
    return sorted(unique_jiras)

def is_date_today(date_string):
    """Check if a date string (YYYY-MM-DD format) is today"""
    if not date_string:
        return False
    try:
        date_obj = datetime.strptime(date_string, '%Y-%m-%d').date()
        today = datetime.now().date()
        return date_obj == today
    except:
        return False

# Initialize cache
load_cache()

def refresh_dashboard_cache():
    """Refresh cache specifically for dashboard performance"""
    global _cache
    
    try:
        user_profile = api.get('user_profile')
        if 'error' not in user_profile:
            if 'results' in user_profile and len(user_profile['results']) > 0:
                _cache['user_profile'] = user_profile['results'][0]
            elif 'id' in user_profile:
                _cache['user_profile'] = user_profile
        
        _cache['dashboard_data'] = {}
        _cache['all_users_data'] = {}
        
        logger.info("Dashboard cache refreshed")
    except Exception as e:
        logger.error(f"Dashboard cache refresh failed: {e}")

def refresh_cache_periodically():
    while True:
        time.sleep(CACHE_TIMEOUT)
        try:
            load_cache()
            logger.info("Cache refreshed")
        except Exception as e:
            logger.error(f"Cache refresh failed: {e}")

cache_thread = threading.Thread(target=refresh_cache_periodically, daemon=True)
cache_thread.start()

@app.route('/')
def dashboard():
    return render_template('dashboard.html')

@app.route('/api/dashboard-data')
def dashboard_data():
    """Enhanced dashboard data for ALL users with flexible filtering"""
    try:
        assigned_to = request.args.get('assigned_to', '')
        view_type = request.args.get('view_type', 'tests_by_assigned')
        
        cache_key = f"dashboard_all_{assigned_to}_{view_type}"
        current_time = datetime.now()
        
        if (cache_key in _cache['all_users_data'] and 
            'timestamp' in _cache['all_users_data'][cache_key] and
            (current_time - _cache['all_users_data'][cache_key]['timestamp']).seconds < DASHBOARD_CACHE_TIMEOUT):
            logger.info(f"Returning cached dashboard data for: {cache_key}")
            return jsonify(_cache['all_users_data'][cache_key]['data'])
        
        logger.info(f"Loading dashboard data for all users, view: {view_type}, assigned_to: {assigned_to}")
        
        if view_type == 'tests_by_assigned':
            all_tests = get_all_tests_by_tags()
            
            if assigned_to:
                all_tests = [test for test in all_tests if str(test.get('lead', '')) == str(assigned_to)]
            
            tests_by_user = {}
            for test in all_tests:
                lead_id = test.get('lead')
                if lead_id:
                    lead_name = _cache['users'].get(lead_id, {}).get('full_name', f'User {lead_id}')
                else:
                    lead_name = 'Unassigned'
                    lead_id = 0
                
                if lead_name not in tests_by_user:
                    tests_by_user[lead_name] = {
                        'pending_by_env': {},
                        'on_hold_by_env': {},
                        'total_pending': 0,
                        'total_on_hold': 0
                    }
                
                branch_tag = test.get('branch_tag', 'Pending')
                environment_id = test.get('environment')
                env_name = _cache['environments'].get(environment_id, 'Unknown') if environment_id else 'Unknown'
                
                if branch_tag == 'Pending':
                    tests_by_user[lead_name]['pending_by_env'][env_name] = tests_by_user[lead_name]['pending_by_env'].get(env_name, 0) + 1
                    tests_by_user[lead_name]['total_pending'] += 1
                elif branch_tag == 'On Hold':
                    tests_by_user[lead_name]['on_hold_by_env'][env_name] = tests_by_user[lead_name]['on_hold_by_env'].get(env_name, 0) + 1
                    tests_by_user[lead_name]['total_on_hold'] += 1
            
            response_data = {
                'success': True,
                'view_type': 'tests_by_assigned',
                'data': tests_by_user,
                'available_users': [{'id': uid, 'name': udata['full_name']} for uid, udata in _cache['users'].items()]
            }
            
        else:
            all_engagements = get_all_engagements()
            all_tests = get_all_tests_by_tags()
            
            if assigned_to:
                all_tests = [test for test in all_tests if str(test.get('lead', '')) == str(assigned_to)]
            
            tests_by_engagement = {}
            for test in all_tests:
                engagement_id = test.get('engagement')
                if engagement_id:
                    engagement_name = _cache['engagements'].get(engagement_id, f'Engagement {engagement_id}')
                    
                    engagement_status = 'Unknown'
                    for eng in all_engagements:
                        if eng['id'] == engagement_id:
                            engagement_status = eng.get('status', 'Unknown')
                            break
                    
                    if engagement_status in ['On Hold', 'In Progress', 'Not Started']:
                        key = f"{engagement_name} ({engagement_status})"
                        
                        if key not in tests_by_engagement:
                            tests_by_engagement[key] = {
                                'pending_by_env': {},
                                'on_hold_by_env': {},
                                'total_pending': 0,
                                'total_on_hold': 0
                            }
                        
                        branch_tag = test.get('branch_tag', 'Pending')
                        environment_id = test.get('environment')
                        env_name = _cache['environments'].get(environment_id, 'Unknown') if environment_id else 'Unknown'
                        
                        if branch_tag == 'Pending':
                            tests_by_engagement[key]['pending_by_env'][env_name] = tests_by_engagement[key]['pending_by_env'].get(env_name, 0) + 1
                            tests_by_engagement[key]['total_pending'] += 1
                        elif branch_tag == 'On Hold':
                            tests_by_engagement[key]['on_hold_by_env'][env_name] = tests_by_engagement[key]['on_hold_by_env'].get(env_name, 0) + 1
                            tests_by_engagement[key]['total_on_hold'] += 1
            
            response_data = {
                'success': True,
                'view_type': 'tests_by_engagement',
                'data': tests_by_engagement,
                'available_users': [{'id': uid, 'name': udata['full_name']} for uid, udata in _cache['users'].items()]
            }
        
        _cache['all_users_data'][cache_key] = {
            'data': response_data,
            'timestamp': current_time
        }
        
        logger.info(f"Dashboard data loaded for view: {view_type}")
        return jsonify(response_data)
        
    except Exception as e:
        logger.error(f"Dashboard data error: {str(e)}")
        return jsonify({
            'success': False, 
            'error': str(e),
            'data': {},
            'available_users': [{'id': uid, 'name': udata['full_name']} for uid, udata in _cache['users'].items()]
        })

@app.route('/api/refresh-dashboard')
def refresh_dashboard_data():
    """Force refresh dashboard data"""
    try:
        refresh_dashboard_cache()
        return jsonify({'success': True, 'message': 'Dashboard data refreshed'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/engagements')
def engagements():
    return render_template('engagements.html')

@app.route('/tests')
def tests():
    return render_template('tests.html')

@app.route('/reassign')
def reassign():
    return render_template('reassign.html')

@app.route('/review')
def review():
    return render_template('review.html')

@app.route('/api/review-engagements')
def api_review_engagements():
    """Get engagements for Review page"""
    try:
        tag_filter = request.args.get('tag', '')
        
        review_engagements = get_review_engagements()
        
        if tag_filter:
            filtered_engagements = []
            for engagement in review_engagements:
                tags = engagement.get('tags', [])
                if tag_filter.lower() in [tag.lower() for tag in tags]:
                    filtered_engagements.append(engagement)
            review_engagements = filtered_engagements
        
        for engagement in review_engagements:
            if engagement.get('lead'):
                engagement['lead_name'] = _cache['users'].get(engagement['lead'], {}).get('full_name', f"User {engagement['lead']}")
            else:
                engagement['lead_name'] = 'Unassigned'
        
        return jsonify({
            'success': True,
            'engagements': review_engagements
        })
        
    except Exception as e:
        logger.error(f"Review engagements error: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e),
            'engagements': []
        })

@app.route('/api/update-engagement-review', methods=['POST'])
def update_engagement_review():
    """Update engagement review using mandatory parameters for engagement PUT"""
    try:
        data = request.json
        engagement_id = data.get('engagement_id')
        commit_hash = data.get('commit_hash')
        branch_tag = data.get('branch_tag')
        
        if not engagement_id or not commit_hash:
            return jsonify({'success': False, 'error': 'Missing engagement ID or review status'})
        
        # Get current engagement data for mandatory parameters
        current_engagement = api.get_single(f'engagements/{engagement_id}')
        if 'error' in current_engagement:
            return jsonify({'success': False, 'error': 'Could not fetch engagement data'})
        
        # Use mandatory parameters: id, name, target_start, target_end, lead, product
        update_data = {
            'id': engagement_id,
            'name': current_engagement.get('name', ''),
            'target_start': current_engagement.get('target_start', ''),
            'target_end': current_engagement.get('target_end', ''),
            'lead': current_engagement.get('lead'),
            'product': current_engagement.get('product'),
            'commit_hash': commit_hash,
            'branch_tag': branch_tag or ''
        }
        
        # Preserve other optional fields
        optional_fields = ['description', 'tags', 'status', 'version', 'build_id', 'created', 'updated', 'reason']
        for field in optional_fields:
            if current_engagement.get(field) is not None:
                update_data[field] = current_engagement[field]
        
        result = api.put(f'engagements/{engagement_id}', update_data)
        
        if 'error' in result:
            return jsonify({'success': False, 'error': result['error']})
        
        return jsonify({
            'success': True,
            'message': 'Review updated successfully with mandatory parameters',
            'updated_engagement': result
        })
        
    except Exception as e:
        logger.error(f"Update engagement review error: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/reassign-tests', methods=['POST'])
def reassign_tests():
    """Reassign selected tests to new user with all mandatory parameters"""
    try:
        data = request.json
        test_ids = data.get('test_ids', [])
        new_lead_id = data.get('new_lead_id')
        num_tests = data.get('num_tests', len(test_ids))
        
        if not test_ids or not new_lead_id:
            return jsonify({'success': False, 'error': 'Missing test IDs or new lead ID'})
        
        if num_tests and num_tests < len(test_ids):
            test_ids = test_ids[:num_tests]
        
        successful_updates = []
        failed_updates = []
        
        for test_id in test_ids:
            try:
                current_test = api.get_single(f'tests/{test_id}')
                if 'error' in current_test:
                    failed_updates.append({'test_id': test_id, 'error': 'Could not fetch test data'})
                    continue
                
                update_data = {
                    'id': test_id,
                    'test_type_name': current_test.get('test_type_name', 'Unknown Test Type'),
                    'title': current_test.get('title', ''),
                    'target_start': current_test.get('target_start', datetime.now().strftime('%Y-%m-%dT%H:%M:%SZ')),
                    'target_end': current_test.get('target_end', datetime.now().strftime('%Y-%m-%dT%H:%M:%SZ')),
                    'lead': int(new_lead_id),
                    'engagement': current_test.get('engagement'),
                    'test_type': current_test.get('test_type'),
                    'environment': current_test.get('environment')
                }
                
                optional_fields = ['description', 'tags', 'branch_tag', 'build_id', 'commit_hash', 'percent_complete']
                for field in optional_fields:
                    if current_test.get(field) is not None:
                        update_data[field] = current_test[field]
                
                result = api.put(f'tests/{test_id}', update_data)
                
                if 'error' in result:
                    failed_updates.append({'test_id': test_id, 'error': result['error']})
                else:
                    successful_updates.append({'test_id': test_id, 'title': current_test.get('title', f'Test {test_id}')})
                    
            except Exception as e:
                failed_updates.append({'test_id': test_id, 'error': str(e)})
        
        return jsonify({
            'success': True,
            'summary': {
                'updated': len(successful_updates),
                'failed': len(failed_updates)
            },
            'details': {
                'successful_updates': successful_updates,
                'failed_updates': failed_updates
            }
        })
        
    except Exception as e:
        logger.error(f"Reassign tests error: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/engagement-filters')
def engagement_filters():
    """Get filter options for engagement dropdowns"""
    try:
        data = api.get('engagements', {'limit': 1000})
        results = data.get('results', [])
        
        allowed_statuses = ['Not Started', 'In Progress', 'On Hold']
        results = [r for r in results if r.get('status') in allowed_statuses]
        
        analysis_statuses = list(set([r.get('status') for r in results if r.get('status')]))
        mentor_reviews = get_unique_values_from_data(results, 'build_id')
        lead_reviews = get_unique_values_from_data(results, 'commit_hash')
        
        all_task_types = set()
        for result in results:
            tags = result.get('tags', [])
            valid_tags = extract_valid_task_types(tags)
            all_task_types.update(valid_tags)
        task_types = sorted(list(all_task_types))
        
        users = [{'id': uid, 'name': udata['full_name']} for uid, udata in _cache['users'].items()]
        products = [{'id': pid, 'name': pname} for pid, pname in _cache['products'].items()]
        
        return jsonify({
            'analysis_statuses': analysis_statuses,
            'mentor_reviews': mentor_reviews,
            'lead_reviews': lead_reviews,
            'task_types': task_types,
            'users': users,
            'products': products
        })
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/api/fetch-engagement-test-counts', methods=['POST'])
def fetch_engagement_test_counts():
    """Fetch test counts for ALL engagements across all pages"""
    try:
        data = request.json or {}
        engagement_ids = data.get('engagement_ids', [])
        
        if not engagement_ids:
            all_engagements = get_all_engagements_for_counts()
            engagement_ids = [eng['id'] for eng in all_engagements]
            logger.info(f"Fetching test counts for ALL {len(engagement_ids)} engagements")
        
        if not engagement_ids:
            return jsonify({'success': False, 'error': 'No engagement IDs available'})
        
        results = {}
        
        for engagement_id in engagement_ids:
            cache_key = f"test_counts_{engagement_id}"
            current_time = datetime.now()
            
            if (cache_key in _cache['engagement_test_counts'] and
                'timestamp' in _cache['engagement_test_counts'][cache_key] and
                (current_time - _cache['engagement_test_counts'][cache_key]['timestamp']).seconds < TEST_COUNTS_CACHE_TIMEOUT):
                cached_counts = _cache['engagement_test_counts'][cache_key]['counts'].copy()
                cached_counts['cached'] = True
                cached_counts['fetched'] = True
                results[engagement_id] = cached_counts
            else:
                counts = calculate_engagement_test_counts(engagement_id)
                counts['cached'] = False
                counts['fetched'] = True
                results[engagement_id] = counts
                
                _cache['engagement_test_counts'][cache_key] = {
                    'counts': counts,
                    'timestamp': current_time
                }
        
        logger.info(f"Fetched test counts for {len(results)} engagements")
        
        return jsonify({
            'success': True,
            'test_counts': results,
            'browser_cache_enabled': True,
            'total_engagements': len(results)
        })
        
    except Exception as e:
        logger.error(f"Error fetching test counts: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/engagements')
def api_engagements():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = 10
        
        created_from = request.args.get('created_from', '')
        created_to = request.args.get('created_to', '')
        name_search = request.args.get('name', '')
        appsec_eta_from = request.args.get('appsec_eta_from', '')
        appsec_eta_to = request.args.get('appsec_eta_to', '')
        rm_eta_from = request.args.get('rm_eta_from', '')
        rm_eta_to = request.args.get('rm_eta_to', '')
        analysis_status = request.args.get('analysis_status', '')
        mentor_review = request.args.get('mentor_review', '')
        lead_review = request.args.get('lead_review', '')
        assigned_to = request.args.get('assigned_to', '')
        product_filter = request.args.get('product', '')
        task_type = request.args.get('task_type', '')
        
        params = {'limit': 1000}
        data = api.get('engagements', params)
        results = data.get('results', [])
        
        allowed_statuses = ['Not Started', 'In Progress', 'On Hold']
        results = [r for r in results if r.get('status') in allowed_statuses]
        
        filtered_results = results.copy()
        
        if created_from or created_to:
            temp_results = []
            for r in filtered_results:
                created_date = r.get('created')
                if created_date:
                    try:
                        created_dt = datetime.fromisoformat(created_date.replace('Z', '+00:00')).date()
                        include = True
                        
                        if created_from:
                            from_dt = datetime.strptime(created_from, '%Y-%m-%d').date()
                            if created_dt < from_dt:
                                include = False
                        
                        if created_to and include:
                            to_dt = datetime.strptime(created_to, '%Y-%m-%d').date()
                            if created_dt > to_dt:
                                include = False
                        
                        if include:
                            temp_results.append(r)
                    except:
                        continue
            filtered_results = temp_results
        
        if appsec_eta_from or appsec_eta_to:
            temp_results = []
            for r in filtered_results:
                target_start = r.get('target_start')
                if target_start:
                    try:
                        target_dt = datetime.strptime(target_start, '%Y-%m-%d').date()
                        include = True
                        
                        if appsec_eta_from:
                            from_dt = datetime.strptime(appsec_eta_from, '%Y-%m-%d').date()
                            if target_dt < from_dt:
                                include = False
                        
                        if appsec_eta_to and include:
                            to_dt = datetime.strptime(appsec_eta_to, '%Y-%m-%d').date()
                            if target_dt > to_dt:
                                include = False
                        
                        if include:
                            temp_results.append(r)
                    except:
                        continue
            filtered_results = temp_results
        
        if rm_eta_from or rm_eta_to:
            temp_results = []
            for r in filtered_results:
                target_end = r.get('target_end')
                if target_end:
                    try:
                        target_dt = datetime.strptime(target_end, '%Y-%m-%d').date()
                        include = True
                        
                        if rm_eta_from:
                            from_dt = datetime.strptime(rm_eta_from, '%Y-%m-%d').date()
                            if target_dt < from_dt:
                                include = False
                        
                        if rm_eta_to and include:
                            to_dt = datetime.strptime(rm_eta_to, '%Y-%m-%d').date()
                            if target_dt > to_dt:
                                include = False
                        
                        if include:
                            temp_results.append(r)
                    except:
                        continue
            filtered_results = temp_results
        
        if name_search:
            filtered_results = [r for r in filtered_results if name_search.lower() in str(r.get('name', '')).lower()]
        
        if analysis_status:
            filtered_results = [r for r in filtered_results if r.get('status') == analysis_status]
        
        if mentor_review:
            filtered_results = [r for r in filtered_results if r.get('build_id') == mentor_review]
        
        if lead_review:
            filtered_results = [r for r in filtered_results if r.get('commit_hash') == lead_review]
        
        if assigned_to:
            filtered_results = [r for r in filtered_results if str(r.get('lead')) == str(assigned_to)]
        
        if product_filter:
            filtered_results = [r for r in filtered_results if str(r.get('product')) == str(product_filter)]
        
        if task_type:
            filtered_results = [r for r in filtered_results if task_type.lower() in [tag.lower() for tag in r.get('tags', [])]]
        
        status_counts = get_status_counts_from_filtered(filtered_results)
        
        for result in filtered_results:
            result['aging'] = calculate_aging(result.get('created'))
            result['formatted_updated'] = format_updated_date(result.get('updated'))
            result['task_types'] = extract_valid_task_types(result.get('tags', []))
            
            if result.get('product'):
                result['product_name'] = _cache['products'].get(result['product'], f"Product {result['product']}")
            if result.get('lead'):
                result['lead_name'] = _cache['users'].get(result['lead'], {}).get('full_name', f"User {result['lead']}")
            
            result['test_counts'] = {'T': 0, 'C': 0, 'P': 0, 'S': 0, 'F': 0, 'D': 0, 'N': 0}
            result['rm_eta_is_today'] = is_date_today(result.get('target_end'))
        
        total = len(filtered_results)
        start = (page - 1) * per_page
        end = start + per_page
        paginated_results = filtered_results[start:end]
        
        return jsonify({
            'results': paginated_results,
            'count': total,
            'page': page,
            'per_page': per_page,
            'total_pages': (total + per_page - 1) // per_page,
            'status_counts': status_counts
        })
    except Exception as e:
        logger.error(f"Engagements API error: {str(e)}")
        return jsonify({'error': str(e), 'results': [], 'count': 0})

@app.route('/api/parse-jira', methods=['POST'])
def parse_jira():
    """Parse JIRA IDs from changelog text"""
    try:
        data = request.json
        text = data.get('text', '')
        
        jira_ids = extract_jira_ids(text)
        
        return jsonify({
            'success': True,
            'jira_ids': jira_ids,
            'count': len(jira_ids)
        })
    except Exception as e:
        logger.error(f"JIRA parsing error: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/create-tests', methods=['POST'])
def create_tests():
    """Create tests for JIRA IDs"""
    try:
        data = request.json
        engagement_id = data.get('engagement_id')
        jira_ids = data.get('jira_ids', [])
        
        if not engagement_id or not jira_ids:
            return jsonify({'success': False, 'error': 'Missing engagement_id or jira_ids'})
        
        engagement_data = api.get_single(f'engagements/{engagement_id}')
        if 'error' in engagement_data:
            return jsonify({'success': False, 'error': f'Failed to fetch engagement: {engagement_data["error"]}'})
        
        existing_tests = api.get('tests', {'engagement': engagement_id, 'limit': 1000})
        existing_titles = [test.get('title', '') for test in existing_tests.get('results', [])]
        
        test_types = api.get('test_types', {'limit': 100})
        environments = api.get('development_environments', {'limit': 100})
        
        default_test_type = None
        default_environment = None
        
        if test_types.get('results'):
            for tt in test_types['results']:
                if 'scan' in tt.get('name', '').lower():
                    default_test_type = tt['id']
                    break
            if not default_test_type:
                default_test_type = test_types['results'][0]['id']
        
        if environments.get('results'):
            default_environment = environments['results'][0]['id']
        
        created_tests = []
        skipped_tests = []
        errors = []
        
        for jira_id in jira_ids:
            if jira_id in existing_titles:
                skipped_tests.append(jira_id)
                continue
            
            test_data = {
                'title': jira_id,
                'engagement': engagement_id,
                'test_type': default_test_type,
                'environment': default_environment,
                'lead': engagement_data.get('lead'),
                'tags': ['jira'],
                'target_start': datetime.now().strftime('%Y-%m-%dT%H:%M:%SZ'),
                'target_end': datetime.now().strftime('%Y-%m-%dT%H:%M:%SZ'),
                'percent_complete': 0,
                'branch_tag': 'Pending',
                'description': f'Test created from JIRA: {jira_id}'
            }
            
            result = api.post('tests', test_data)
            
            if 'error' in result:
                errors.append(f'{jira_id}: {result["error"]}')
            else:
                created_tests.append({
                    'jira_id': jira_id,
                    'test_id': result.get('id'),
                    'title': result.get('title')
                })
        
        return jsonify({
            'success': True,
            'summary': {
                'created': len(created_tests),
                'skipped': len(skipped_tests),
                'errors': len(errors)
            },
            'details': {
                'created_tests': created_tests,
                'skipped_tests': skipped_tests,
                'errors': errors
            }
        })
    
    except Exception as e:
        logger.error(f"Test creation error: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/engagements/<int:eng_id>')
def api_engagement_detail(eng_id):
    try:
        data = api.get_single(f'engagements/{eng_id}')
        if 'error' not in data:
            if data.get('product'):
                data['product_name'] = _cache['products'].get(data['product'], f"Product {data['product']}")
            if data.get('lead'):
                data['lead_name'] = _cache['users'].get(data['lead'], {}).get('full_name', f"User {data['lead']}")
        return jsonify(data)
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/api/engagements', methods=['POST'])
def create_engagement():
    """Create engagement with Created by (reason) field"""
    try:
        data = request.json
        
        if 'reason' in data:
            logger.info(f"Creating engagement with Created by: {data['reason']}")
        
        result = api.post('engagements', data)
        if 'error' in result:
            return jsonify({'success': False, 'error': result['error']})
        return jsonify({'success': True, 'data': result})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/engagements/<int:eng_id>', methods=['PUT'])
def update_engagement(eng_id):
    """Update engagement with mandatory parameters"""
    try:
        data = request.json
        
        current_engagement = api.get_single(f'engagements/{eng_id}')
        if 'error' in current_engagement:
            return jsonify({'success': False, 'error': 'Could not fetch current engagement data'})
        
        complete_data = {
            'id': eng_id,
            'name': current_engagement.get('name', ''),
            'target_start': current_engagement.get('target_start', ''),
            'target_end': current_engagement.get('target_end', ''),
            'lead': current_engagement.get('lead'),
            'product': current_engagement.get('product')
        }
        
        complete_data.update(data)
        
        optional_fields = ['description', 'tags', 'status', 'version', 'build_id', 'commit_hash', 'reason', 'created', 'updated']
        for field in optional_fields:
            if field in data:
                complete_data[field] = data[field]
            elif current_engagement.get(field) is not None:
                complete_data[field] = current_engagement[field]
        
        result = api.put(f'engagements/{eng_id}', complete_data)
        if 'error' in result:
            return jsonify({'success': False, 'error': result['error']})
        return jsonify({'success': True, 'data': result})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/engagements/<int:eng_id>/close', methods=['POST'])
def close_engagement(eng_id):
    """Close engagement using close API endpoint"""
    try:
        # Call the close endpoint
        result = api.post(f'engagements/{eng_id}/close', {})
        
        if 'error' in result:
            return jsonify({'success': False, 'error': result['error']})
        
        return jsonify({'success': True, 'message': 'Engagement closed successfully'})
        
    except Exception as e:
        logger.error(f"Close engagement error: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/engagements/<int:eng_id>', methods=['DELETE'])
def delete_engagement(eng_id):
    try:
        result = api.delete(f'engagements/{eng_id}')
        return jsonify(result)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# Enhanced Tests API
@app.route('/api/test-filters')
def test_filters():
    """Get filter options for test dropdowns"""
    try:
        params = {'limit': 1000}
        data = api.get('tests', params)
        results = data.get('results', [])
        
        jira_tests = []
        for test in results:
            tags = test.get('tags', [])
            branch_tag = test.get('branch_tag', 'Pending')
            
            if 'jira' in [tag.lower() for tag in tags] and branch_tag not in ['Approved', 'Rejected']:
                jira_tests.append(test)
        
        jira_statuses = get_unique_values_from_data(jira_tests, 'build_id')
        issue_types = get_unique_values_from_data(jira_tests, 'commit_hash')
        analysis_statuses = ['On Hold', 'Pending']
        
        users = [{'id': uid, 'name': udata['full_name']} for uid, udata in _cache['users'].items()]
        engagements = [{'id': eid, 'name': ename} for eid, ename in _cache['engagements'].items()]
        environments = [{'id': eid, 'name': ename} for eid, ename in _cache['environments'].items()]
        
        status_counts = get_status_counts_from_filtered_tests(jira_tests)
        
        return jsonify({
            'jira_statuses': jira_statuses,
            'issue_types': issue_types,
            'analysis_statuses': analysis_statuses,
            'users': users,
            'engagements': engagements,
            'environments': environments,
            'status_counts': status_counts
        })
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/api/tests')
def api_tests():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = 10
        
        title_search = request.args.get('title', '')
        jira_status = request.args.get('jira_status', '')
        issue_type = request.args.get('issue_type', '')
        analysis_status = request.args.get('analysis_status', '')
        engagement_filter = request.args.get('engagement', '')
        lead_filter = request.args.get('lead', '')
        environment_filter = request.args.get('environment', '')
        apply_filters = request.args.get('apply_filters', 'false') == 'true'
        
        if not apply_filters and not any([title_search, jira_status, issue_type, analysis_status, engagement_filter, lead_filter, environment_filter]):
            params = {'limit': 1000}
            data = api.get('tests', params)
            results = data.get('results', [])
            
            jira_tests = []
            for test in results:
                tags = test.get('tags', [])
                branch_tag = test.get('branch_tag', 'Pending')
                
                if 'jira' in [tag.lower() for tag in tags] and branch_tag not in ['Approved', 'Rejected']:
                    jira_tests.append(test)
            
            status_counts = get_status_counts_from_filtered_tests(jira_tests)
            
            return jsonify({
                'results': [],
                'count': 0,
                'page': 1,
                'per_page': per_page,
                'total_pages': 0,
                'status_counts': status_counts
            })
        
        params = {'limit': 1000}
        data = api.get('tests', params)
        results = data.get('results', [])
        
        filtered_results = []
        for test in results:
            tags = test.get('tags', [])
            branch_tag = test.get('branch_tag', 'Pending')
            
            if 'jira' in [tag.lower() for tag in tags] and branch_tag not in ['Approved', 'Rejected']:
                filtered_results.append(test)
        
        if title_search:
            filtered_results = [t for t in filtered_results if title_search.lower() in str(t.get('title', '')).lower()]
        
        if jira_status:
            filtered_results = [t for t in filtered_results if t.get('build_id') == jira_status]
        
        if issue_type:
            filtered_results = [t for t in filtered_results if t.get('commit_hash') == issue_type]
        
        if analysis_status:
            filtered_results = [t for t in filtered_results if t.get('branch_tag') == analysis_status]
        
        if engagement_filter:
            filtered_results = [t for t in filtered_results if str(t.get('engagement')) == str(engagement_filter)]
        
        if lead_filter:
            filtered_results = [t for t in filtered_results if str(t.get('lead')) == str(lead_filter)]
        
        if environment_filter:
            filtered_results = [t for t in filtered_results if str(t.get('environment')) == str(environment_filter)]
        
        status_counts = get_status_counts_from_filtered_tests(filtered_results)
        
        for result in filtered_results:
            if result.get('engagement'):
                result['engagement_name'] = _cache['engagements'].get(result['engagement'], f"Engagement {result['engagement']}")
            
            if result.get('lead'):
                result['lead_name'] = _cache['users'].get(result['lead'], {}).get('full_name', f"User {result['lead']}")
            
            if result.get('environment'):
                result['environment_name'] = _cache['environments'].get(result['environment'], f"Environment {result['environment']}")
            
            if not result.get('branch_tag'):
                result['branch_tag'] = 'Pending'
        
        total = len(filtered_results)
        start = (page - 1) * per_page
        end = start + per_page
        paginated_results = filtered_results[start:end]
        
        return jsonify({
            'results': paginated_results,
            'count': total,
            'page': page,
            'per_page': per_page,
            'total_pages': (total + per_page - 1) // per_page,
            'status_counts': status_counts
        })
    except Exception as e:
        logger.error(f"Tests API error: {str(e)}")
        return jsonify({'error': str(e), 'results': [], 'count': 0})

@app.route('/api/tests/<int:test_id>', methods=['PUT'])
def update_test(test_id):
    """Update test with all mandatory fields"""
    try:
        current_test = api.get_single(f'tests/{test_id}')
        if 'error' in current_test:
            return jsonify({'success': False, 'error': f'Failed to fetch current test data: {current_test["error"]}'})
        
        update_data = request.json
        
        test_type_name = current_test.get('test_type_name')
        if current_test.get('test_type') and not test_type_name:
            test_type_name = _cache['test_types'].get(current_test['test_type'], 'Unknown Test Type')
        
        complete_data = {
            'id': test_id,
            'test_type_name': test_type_name or current_test.get('test_type_name', 'Unknown Test Type'),
            'title': current_test.get('title', ''),
            'target_start': current_test.get('target_start', datetime.now().strftime('%Y-%m-%dT%H:%M:%SZ')),
            'target_end': current_test.get('target_end', datetime.now().strftime('%Y-%m-%dT%H:%M:%SZ')),
            'lead': current_test.get('lead'),
            'engagement': current_test.get('engagement'),
            'test_type': current_test.get('test_type'),
            'environment': current_test.get('environment')
        }
        
        complete_data.update(update_data)
        
        result = api.put(f'tests/{test_id}', complete_data)
        
        if 'error' in result:
            return jsonify({'success': False, 'error': result['error']})
        return jsonify({'success': True, 'data': result})
    except Exception as e:
        logger.error(f"Test update error: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

if __name__ == '__main__':
    import webbrowser
    import threading
    import time
    
    def open_browser():
        time.sleep(1.5)
        webbrowser.open('http://localhost:5000')
    
    threading.Thread(target=open_browser).start()
    app.run(debug=True, host='localhost', port=5000)
'''

project_files['app.pyw'] = app_py_content

print("Created enhanced Flask application with updated Review tab logic")