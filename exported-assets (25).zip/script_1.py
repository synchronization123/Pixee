# Create enhanced Dojo.pyw with all requested improvements
dojo_gui_content = '''
import tkinter as tk
from tkinter import messagebox, simpledialog, ttk
import json
import requests
import os
import sys
import subprocess
import zipfile
import threading
import time
import psutil
from datetime import datetime
import pystray
from pystray import MenuItem as item
from PIL import Image, ImageDraw

class DefectDojoLauncher:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("DefectDojo Clone - Enhanced Launcher & Auto-Updater v8")
        # ENHANCED: Make GUI bigger to fit all buttons properly
        self.root.geometry("550x450")
        self.root.resizable(False, False)
        
        # Center the window
        self.center_window()
        
        # Set icon
        try:
            self.root.iconbitmap(default=self.create_icon_file())
        except:
            pass  # Icon creation failed, continue without
        
        # Load current configuration
        self.load_config()
        
        # Create GUI elements
        self.create_widgets()
        
        # System tray setup
        self.tray_icon = None
        self.app_processes = []  # ENHANCED: Track all app processes
        
    def center_window(self):
        """Center the window on screen"""
        self.root.withdraw()
        self.root.update_idletasks()
        # ENHANCED: Updated for bigger window
        x = (self.root.winfo_screenwidth() // 2) - (550 // 2)
        y = (self.root.winfo_screenheight() // 2) - (450 // 2)
        self.root.geometry(f"550x450+{x}+{y}")
        self.root.deiconify()
    
    def create_icon_file(self):
        """Create a simple icon file for the application"""
        try:
            # Create a simple shield icon
            image = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
            dc = ImageDraw.Draw(image)
            
            # Draw shield shape
            dc.rectangle([10, 10, 54, 54], fill=(52, 152, 219), outline=(41, 128, 185), width=2)
            dc.text((20, 25), "DD", fill="white")
            
            # Save as ico file
            icon_path = "dojo_icon.ico"
            image.save(icon_path, format='ICO')
            return icon_path
        except Exception:
            return None
    
    def load_config(self):
        """Load configuration from files"""
        try:
            # Load token configuration
            with open('token.json', 'r') as f:
                self.token_config = json.load(f)
                self.current_token = self.token_config.get('api_token', '')
                self.base_url = self.token_config.get('base_url', 'https://demo.defectdojo.org')
        except Exception as e:
            self.current_token = ''
            self.base_url = 'https://demo.defectdojo.org'
            self.token_config = {'api_token': '', 'base_url': self.base_url}
        
        try:
            # ENHANCED: Fetch version from version.json
            with open('version.json', 'r') as f:
                self.version_config = json.load(f)
                self.current_version = self.version_config.get('version', '1.0')
        except Exception as e:
            self.current_version = '1.0'
            self.version_config = {'version': '1.0', 'last_updated': datetime.now().strftime('%Y-%m-%d')}
            self.save_version_config()
    
    def save_token_config(self):
        """Save token configuration to file"""
        try:
            with open('token.json', 'w') as f:
                json.dump(self.token_config, f, indent=2)
            return True
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save token config: {str(e)}")
            return False
    
    def save_version_config(self):
        """Save version configuration to file"""
        try:
            with open('version.json', 'w') as f:
                json.dump(self.version_config, f, indent=2)
            return True
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save version config: {str(e)}")
            return False
    
    def create_widgets(self):
        """Create all GUI widgets"""
        # Main frame
        main_frame = tk.Frame(self.root, bg="#f0f0f0")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Title
        title_label = tk.Label(main_frame, text="🛡️ DefectDojo Clone v8", font=("Arial", 18, "bold"), 
                              bg="#f0f0f0", fg="#2c3e50")
        title_label.pack(pady=(0, 5))
        
        subtitle_label = tk.Label(main_frame, text="Enhanced Auto-Updater & Portal Launcher", 
                                 font=("Arial", 10), bg="#f0f0f0", fg="#7f8c8d")
        subtitle_label.pack(pady=(0, 15))
        
        # Current configuration frame
        config_frame = tk.LabelFrame(main_frame, text="Current Configuration", font=("Arial", 10, "bold"),
                                   bg="#f0f0f0", fg="#2c3e50")
        config_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Token display (masked)
        token_frame = tk.Frame(config_frame, bg="#f0f0f0")
        token_frame.pack(fill=tk.X, padx=10, pady=5)
        
        tk.Label(token_frame, text="API Token:", font=("Arial", 9), bg="#f0f0f0", fg="#34495e").pack(side=tk.LEFT)
        token_display = self.mask_token(self.current_token)
        self.token_label = tk.Label(token_frame, text=token_display, font=("Courier", 9), 
                                   bg="#f0f0f0", fg="#e74c3c")
        self.token_label.pack(side=tk.LEFT, padx=(10, 0))
        
        # Version display
        version_frame = tk.Frame(config_frame, bg="#f0f0f0")
        version_frame.pack(fill=tk.X, padx=10, pady=5)
        
        tk.Label(version_frame, text="Version:", font=("Arial", 9), bg="#f0f0f0", fg="#34495e").pack(side=tk.LEFT)
        tk.Label(version_frame, text=f"v{self.current_version}", font=("Arial", 9), 
                bg="#f0f0f0", fg="#27ae60").pack(side=tk.LEFT, padx=(10, 0))
        
        # Action buttons frame
        actions_frame = tk.LabelFrame(main_frame, text="Actions", font=("Arial", 10, "bold"),
                                    bg="#f0f0f0", fg="#2c3e50")
        actions_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Update token button
        update_token_btn = tk.Button(actions_frame, text="🔑 Update Token", 
                                   command=self.update_token, font=("Arial", 10), 
                                   bg="#f39c12", fg="white", relief=tk.FLAT, pady=8)
        update_token_btn.pack(fill=tk.X, padx=10, pady=(10, 5))
        
        # ENHANCED: Execute app.pyw button
        self.execute_btn = tk.Button(actions_frame, text="▶️ Execute Portal (app.pyw)", 
                                   command=self.execute_portal, font=("Arial", 10), 
                                   bg="#9b59b6", fg="white", relief=tk.FLAT, pady=8)
        self.execute_btn.pack(fill=tk.X, padx=10, pady=(5, 5))
        
        # Launch portal button with version check
        self.launch_btn = tk.Button(actions_frame, text="🚀 Launch Portal (with Auto-Update)", 
                                  command=self.launch_portal, font=("Arial", 12, "bold"), 
                                  bg="#27ae60", fg="white", relief=tk.FLAT, pady=12)
        self.launch_btn.pack(fill=tk.X, padx=10, pady=(5, 5))
        
        # ENHANCED: Hide to tray button
        hide_tray_btn = tk.Button(actions_frame, text="📱 Hide to System Tray", 
                                command=self.hide_to_tray_manual, font=("Arial", 10), 
                                bg="#34495e", fg="white", relief=tk.FLAT, pady=8)
        hide_tray_btn.pack(fill=tk.X, padx=10, pady=(5, 10))
        
        # Status frame
        status_frame = tk.LabelFrame(main_frame, text="Status", font=("Arial", 10, "bold"),
                                   bg="#f0f0f0", fg="#2c3e50")
        status_frame.pack(fill=tk.X)
        
        self.status_label = tk.Label(status_frame, text="Ready", font=("Arial", 9), 
                                   bg="#f0f0f0", fg="#27ae60")
        self.status_label.pack(padx=10, pady=10)
        
        # Progress bar (hidden by default)
        self.progress_bar = ttk.Progressbar(status_frame, mode='indeterminate')
        self.progress_bar.pack(fill=tk.X, padx=10, pady=(0, 10))
        self.progress_bar.pack_forget()
    
    def mask_token(self, token):
        """Mask API token for display"""
        if not token:
            return "****"
        if len(token) <= 8:
            return "*" * len(token)
        return token[:4] + "*" * (len(token) - 8) + token[-4:]
    
    def update_token(self):
        """Update API token"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Update API Token")
        dialog.geometry("400x150")
        dialog.resizable(False, False)
        
        # Center dialog
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Center the dialog
        dialog.withdraw()
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() // 2) - (400 // 2)
        y = (dialog.winfo_screenheight() // 2) - (150 // 2)
        dialog.geometry(f"400x150+{x}+{y}")
        dialog.deiconify()
        
        frame = tk.Frame(dialog, bg="#f0f0f0")
        frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(frame, text="Enter new API Token:", font=("Arial", 10, "bold"), 
                bg="#f0f0f0", fg="#2c3e50").pack(pady=(0, 10))
        
        token_entry = tk.Entry(frame, font=("Courier", 9), show="*", width=50)
        token_entry.pack(fill=tk.X, pady=(0, 15))
        token_entry.insert(0, self.current_token)
        token_entry.select_range(0, tk.END)
        token_entry.focus()
        
        def save_token():
            new_token = token_entry.get().strip()
            
            if not new_token:
                messagebox.showerror("Error", "Token cannot be empty")
                return
            
            self.current_token = new_token
            self.token_config['api_token'] = new_token
            
            if self.save_token_config():
                # Update display
                self.token_label.config(text=self.mask_token(new_token))
                messagebox.showinfo("Success", "Token updated successfully!")
                dialog.destroy()
        
        # Buttons
        btn_frame = tk.Frame(frame, bg="#f0f0f0")
        btn_frame.pack(fill=tk.X)
        
        tk.Button(btn_frame, text="Cancel", command=dialog.destroy, 
                 font=("Arial", 9), bg="#95a5a6", fg="white", relief=tk.FLAT, pady=5).pack(side=tk.RIGHT, padx=(5, 0))
        tk.Button(btn_frame, text="Save", command=save_token, 
                 font=("Arial", 9), bg="#3498db", fg="white", relief=tk.FLAT, pady=5).pack(side=tk.RIGHT)
        
        # Bind Enter key
        token_entry.bind('<Return>', lambda e: save_token())
    
    def execute_portal(self):
        """ENHANCED: Execute app.pyw directly without version checking"""
        if not self.current_token:
            messagebox.showerror("Error", "Please set API token first")
            return
        
        if not os.path.exists('app.pyw'):
            messagebox.showerror("Error", "app.pyw not found in current directory")
            return
        
        try:
            self.status_label.config(text="Launching portal directly...", fg="#3498db")
            
            # ENHANCED: Check if app.pyw is already running to prevent double execution
            for process in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    if process.info['cmdline'] and 'app.pyw' in ' '.join(process.info['cmdline']):
                        self.status_label.config(text="Portal already running", fg="#f39c12")
                        messagebox.showinfo("Info", "Portal is already running!")
                        return
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            # Launch the application
            app_process = subprocess.Popen([sys.executable, 'app.pyw'], 
                                         creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
            
            self.app_processes.append(app_process)
            self.status_label.config(text="Portal launched successfully", fg="#27ae60")
            
            messagebox.showinfo("Success", "Portal launched successfully!\\nYou can now hide this launcher to system tray.")
            
        except Exception as e:
            messagebox.showerror("Launch Error", f"Failed to launch portal:\\n\\n{str(e)}")
            self.status_label.config(text="Launch failed", fg="#e74c3c")
    
    def launch_portal(self):
        """Launch the DefectDojo portal with version checking and auto-update"""
        if not self.current_token:
            messagebox.showerror("Error", "Please set API token first")
            return
        
        if not os.path.exists('app.pyw'):
            messagebox.showerror("Error", "app.pyw not found in current directory")
            return
        
        self.status_label.config(text="Checking version...", fg="#f39c12")
        self.progress_bar.pack(fill=tk.X, padx=10, pady=(0, 10))
        self.progress_bar.start()
        self.launch_btn.config(state=tk.DISABLED)
        self.execute_btn.config(state=tk.DISABLED)
        
        # Run version check in separate thread
        def version_check_thread():
            try:
                # Check version from engagement endpoint
                headers = {'Authorization': f'Token {self.current_token}'}
                response = requests.get(f'{self.base_url}/api/v2/engagements/1/', 
                                      headers=headers, timeout=10)
                
                if response.status_code == 200:
                    data = response.json()
                    server_version = data.get('version', '1.0')
                    
                    # Compare versions
                    if server_version == self.current_version:
                        # Versions match, launch directly
                        self.root.after(0, self.launch_app_directly)
                    else:
                        # Versions don't match, download update
                        self.root.after(0, lambda: self.download_and_update(server_version))
                else:
                    self.root.after(0, lambda: self.version_check_error(f"HTTP {response.status_code}: Could not check version"))
            
            except Exception as e:
                self.root.after(0, lambda: self.version_check_error(str(e)))
        
        threading.Thread(target=version_check_thread, daemon=True).start()
    
    def launch_app_directly(self):
        """Launch app directly when versions match"""
        try:
            self.progress_bar.stop()
            self.progress_bar.pack_forget()
            self.status_label.config(text="Launching portal...", fg="#3498db")
            
            # ENHANCED: Check if app.pyw is already running to prevent double execution
            for process in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    if process.info['cmdline'] and 'app.pyw' in ' '.join(process.info['cmdline']):
                        self.status_label.config(text="Portal already running", fg="#f39c12")
                        self.launch_btn.config(state=tk.NORMAL)
                        self.execute_btn.config(state=tk.NORMAL)
                        messagebox.showinfo("Info", "Portal is already running!")
                        return
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            # Launch the application
            app_process = subprocess.Popen([sys.executable, 'app.pyw'], 
                                         creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
            
            self.app_processes.append(app_process)
            
            # ENHANCED: Automatically hide to system tray after launching
            self.hide_to_tray()
            
        except Exception as e:
            messagebox.showerror("Launch Error", f"Failed to launch portal:\\n\\n{str(e)}")
            self.status_label.config(text="Launch failed", fg="#e74c3c")
            self.launch_btn.config(state=tk.NORMAL)
            self.execute_btn.config(state=tk.NORMAL)
    
    def download_and_update(self, new_version):
        """ENHANCED: Download and install update from new URL"""
        self.status_label.config(text="Downloading update...", fg="#f39c12")
        
        def download_thread():
            try:
                # ENHANCED: Download update from new URL
                headers = {'Authorization': f'Token {self.current_token}'}
                response = requests.get(f'{self.base_url}/api/v2/engagements/3/files/download/5/', 
                                      headers=headers, timeout=30, stream=True)
                
                if response.status_code == 200:
                    # Save update file
                    update_file = 'defectdojo_update.zip'
                    with open(update_file, 'wb') as f:
                        for chunk in response.iter_content(chunk_size=8192):
                            f.write(chunk)
                    
                    self.root.after(0, lambda: self.install_update(update_file, new_version))
                else:
                    self.root.after(0, lambda: self.update_error(f"HTTP {response.status_code}: Could not download update"))
            
            except Exception as e:
                self.root.after(0, lambda: self.update_error(str(e)))
        
        threading.Thread(target=download_thread, daemon=True).start()
    
    def install_update(self, update_file, new_version):
        """ENHANCED: Install downloaded update (preserve Dojo.pyw)"""
        try:
            self.status_label.config(text="Installing update...", fg="#f39c12")
            
            # ENHANCED: Extract update but preserve Dojo.pyw
            with zipfile.ZipFile(update_file, 'r') as zip_ref:
                for file_info in zip_ref.infolist():
                    # Skip Dojo.pyw to preserve current launcher
                    if not file_info.filename.endswith('Dojo.pyw'):
                        zip_ref.extract(file_info, '.')
            
            # Update version
            self.current_version = new_version
            self.version_config['version'] = new_version
            self.version_config['last_updated'] = datetime.now().strftime('%Y-%m-%d')
            self.save_version_config()
            
            # ENHANCED: Clean up - delete zip file
            os.remove(update_file)
            
            self.progress_bar.stop()
            self.progress_bar.pack_forget()
            self.status_label.config(text="Update installed! Launching...", fg="#27ae60")
            
            # Launch updated app
            self.launch_app_directly()
            
        except Exception as e:
            self.update_error(f"Installation failed: {str(e)}")
    
    def version_check_error(self, error_msg):
        """Handle version check errors"""
        self.progress_bar.stop()
        self.progress_bar.pack_forget()
        self.launch_btn.config(state=tk.NORMAL)
        self.execute_btn.config(state=tk.NORMAL)
        self.status_label.config(text="Version check failed", fg="#e74c3c")
        
        result = messagebox.askyesno("Version Check Failed", 
                                   f"Could not check for updates:\\n\\n{error_msg}\\n\\nLaunch anyway?")
        if result:
            self.launch_app_directly()
    
    def update_error(self, error_msg):
        """Handle update errors"""
        self.progress_bar.stop()
        self.progress_bar.pack_forget()
        self.launch_btn.config(state=tk.NORMAL)
        self.execute_btn.config(state=tk.NORMAL)
        self.status_label.config(text="Update failed", fg="#e74c3c")
        
        result = messagebox.askyesno("Update Failed", 
                                   f"Could not install update:\\n\\n{error_msg}\\n\\nLaunch current version?")
        if result:
            self.launch_app_directly()
    
    def hide_to_tray_manual(self):
        """ENHANCED: Manually hide to system tray"""
        self.hide_to_tray()
        messagebox.showinfo("Hidden to Tray", "Application hidden to system tray.\\nRight-click the tray icon to restore or exit.")
    
    def hide_to_tray(self):
        """ENHANCED: Hide application to system tray with restore and exit options"""
        try:
            # Create system tray icon
            image = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
            dc = ImageDraw.Draw(image)
            dc.rectangle([10, 10, 54, 54], fill=(52, 152, 219), outline=(41, 128, 185), width=2)
            dc.text((20, 25), "DD", fill="white")
            
            # ENHANCED: Menu with restore and exit options
            menu = pystray.Menu(
                item('Show Launcher', self.show_from_tray),
                item('Exit (Kill All)', self.quit_application)
            )
            
            self.tray_icon = pystray.Icon("DefectDojo", image, "DefectDojo Clone Launcher", menu)
            
            # Hide main window
            self.root.withdraw()
            
            # Start tray icon in separate thread
            threading.Thread(target=self.tray_icon.run, daemon=True).start()
            
            self.status_label.config(text="Hidden to system tray", fg="#27ae60")
            
        except Exception as e:
            print(f"Could not minimize to tray: {e}")
            # Just minimize normally if tray fails
            self.root.iconify()
    
    def show_from_tray(self):
        """Show application from system tray"""
        self.root.deiconify()
        self.root.lift()
        if self.tray_icon:
            self.tray_icon.stop()
    
    def quit_application(self):
        """ENHANCED: Quit the entire application and kill all app.pyw processes"""
        try:
            # ENHANCED: Kill all app.pyw processes
            self.kill_app_processes()
            
            # Stop tray icon
            if self.tray_icon:
                self.tray_icon.stop()
            
            # Quit main application
            self.root.quit()
            
        except Exception:
            pass
        finally:
            sys.exit(0)
    
    def kill_app_processes(self):
        """ENHANCED: Kill all app.pyw processes"""
        try:
            # Kill tracked processes
            for process in self.app_processes:
                try:
                    if process.poll() is None:  # Process is still running
                        process.terminate()
                        process.wait(timeout=5)
                except:
                    pass
            
            # Also search for any remaining app.pyw processes
            for process in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    if process.info['cmdline'] and 'app.pyw' in ' '.join(process.info['cmdline']):
                        process.terminate()
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
                    
            self.app_processes = []
            
        except Exception as e:
            print(f"Error killing app processes: {e}")
    
    def run(self):
        """Run the application"""
        try:
            # Handle window close
            self.root.protocol("WM_DELETE_WINDOW", self.quit_application)
            
            # Start main loop
            self.root.mainloop()
            
        except Exception as e:
            messagebox.showerror("Application Error", f"Application error:\\n\\n{str(e)}")
        finally:
            self.quit_application()

if __name__ == "__main__":
    try:
        app = DefectDojoLauncher()
        app.run()
    except Exception as e:
        import tkinter.messagebox
        tkinter.messagebox.showerror("Startup Error", f"Failed to start application:\\n\\n{str(e)}")
        sys.exit(1)
'''

project_files['Dojo.pyw'] = dojo_gui_content

print("Created enhanced Dojo.pyw with all v8 improvements")