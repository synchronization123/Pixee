# Create Tests and Reassign templates for v8 (same as before but with v8 branding)

tests_template = '''{% extends "base.html" %}

{% block title %}Tests - DefectDojo Clone v8{% endblock %}

{% block content %}
<div class="page-header">
    <h1 class="page-title">Tests</h1>
    
    <div class="status-counts" id="testStatusCounts">
        <div class="status-count">Pending: <span id="pendingCount">0</span></div>
        <div class="status-count">On Hold: <span id="onHoldCount">0</span></div>
    </div>
    
    <div class="btn-group">
        <button type="button" class="btn btn-secondary" onclick="refreshTable()">
            🔄 Refresh
        </button>
    </div>
</div>

<div id="alert-container"></div>

<div class="filters">
    <div class="filter-grid-wide">
        <div class="form-group">
            <label class="form-label">Jira</label>
            <input type="text" class="form-control" id="titleFilter" placeholder="Search by JIRA ID...">
        </div>
        <div class="form-group">
            <label class="form-label">Jira Status</label>
            <select class="form-control" id="jiraStatusFilter">
                <option value="">All Jira Statuses</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">Issue Type</label>
            <select class="form-control" id="issueTypeFilter">
                <option value="">All Issue Types</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">Analysis Status</label>
            <select class="form-control" id="analysisStatusFilter">
                <option value="">All Statuses</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">Engagement</label>
            <select class="form-control" id="engagementFilter">
                <option value="">All Engagements</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">Assigned To</label>
            <select class="form-control" id="assignedToFilter">
                <option value="">All Users</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">Type</label>
            <select class="form-control" id="environmentFilter">
                <option value="">All Types</option>
            </select>
        </div>
        <div class="form-group">
            <button type="button" class="btn btn-primary" onclick="applyFilters()">
                🔍 Go
            </button>
        </div>
        <div class="form-group">
            <button type="button" class="btn btn-secondary" onclick="resetFilters()">
                🔄 Reset
            </button>
        </div>
    </div>
</div>

<div id="noDataMessage" class="card" style="display: block;">
    <div class="card-body text-center" style="padding: 60px;">
        <h3 style="color: #666; margin-bottom: 20px;">🔍 Apply Filters to View Tests</h3>
        <p style="color: #888; font-size: 16px;">Use the filters above to search for JIRA tests.<br>
        Data is not loaded by default for better performance.</p>
    </div>
</div>

<div class="pagination-info" id="paginationInfo" style="display: none;">
    <div class="total-records">
        Total Records: <span id="totalRecords">0</span>
    </div>
    <div class="pagination-controls" id="paginationTop">
    </div>
</div>

<div class="card" id="testsTableCard" style="display: none;">
    <div class="card-header">
        🧪 JIRA Tests List v8 (All Updates Use Mandatory Parameters)
    </div>
    <div class="card-body">
        <div class="table-container">
            <table class="table" id="testsTable">
                <thead>
                    <tr>
                        <th style="min-width: 60px;">ID</th>
                        <th style="min-width: 120px;">Jira</th>
                        <th style="min-width: 120px;">Jira Status</th>
                        <th style="min-width: 120px;">Issue Type</th>
                        <th style="min-width: 140px;">Analysis Status</th>
                        <th style="min-width: 200px;">Engagement</th>
                        <th style="min-width: 150px;">Assigned To</th>
                        <th style="min-width: 120px;">Type</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
        
        <div class="pagination" id="paginationBottom">
        </div>
    </div>
</div>
{% endblock %}

{% block extra_js %}
<script>
let currentPage = 1;
let totalPages = 1;
let totalRecords = 0;
let currentFilters = {};
let filterOptions = {};
let hasFiltersApplied = false;
let testCache = {};

const debouncedLoadTests = debounce(loadTests, 300);

async function loadFilterOptions() {
    try {
        const response = await apiCall('/api/test-filters');
        filterOptions = response;
        
        populateSelectOptions('jiraStatusFilter', response.jira_statuses.map(s => ({value: s, text: s || 'Empty'})));
        populateSelectOptions('issueTypeFilter', response.issue_types.map(s => ({value: s, text: s || 'Empty'})));
        populateSelectOptions('analysisStatusFilter', response.analysis_statuses.map(s => ({value: s, text: s})));
        populateSelectOptions('assignedToFilter', response.users.map(u => ({value: u.id, text: u.name})));
        populateSelectOptions('engagementFilter', response.engagements.map(e => ({value: e.id, text: e.name})));
        populateSelectOptions('environmentFilter', response.environments.map(e => ({value: e.id, text: e.name})));
        
        if (response.status_counts) {
            updateStatusCounts(response.status_counts);
        }
        
    } catch (error) {
        console.error('Failed to load filter options:', error);
    }
}

function populateSelectOptions(selectId, options) {
    const select = document.getElementById(selectId);
    const currentValue = select.value;
    
    const firstOption = select.options[0];
    select.innerHTML = '';
    select.appendChild(firstOption);
    
    options.forEach(option => {
        const optElement = document.createElement('option');
        optElement.value = option.value;
        optElement.textContent = option.text;
        select.appendChild(optElement);
    });
    
    select.value = currentValue;
}

function updateStatusCounts(counts) {
    document.getElementById('pendingCount').textContent = counts['Pending'] || 0;
    document.getElementById('onHoldCount').textContent = counts['On Hold'] || 0;
}

async function loadTests(page = 1, filters = {}, applyFilters = false) {
    try {
        const params = new URLSearchParams({
            page: page,
            apply_filters: applyFilters.toString(),
            ...filters
        });
        
        const response = await apiCall(`/api/tests?${params}`);
        displayTests(response.results || []);
        
        (response.results || []).forEach(test => {
            testCache[test.id] = test;
        });
        
        currentPage = response.page || 1;
        totalPages = response.total_pages || 1;
        totalRecords = response.count || 0;
        
        if (response.status_counts) {
            updateStatusCounts(response.status_counts);
        }
        
        if (applyFilters || totalRecords > 0) {
            document.getElementById('noDataMessage').style.display = 'none';
            document.getElementById('testsTableCard').style.display = 'block';
            document.getElementById('paginationInfo').style.display = 'flex';
            hasFiltersApplied = true;
        } else {
            document.getElementById('noDataMessage').style.display = 'block';
            document.getElementById('testsTableCard').style.display = 'none';
            document.getElementById('paginationInfo').style.display = 'none';
            hasFiltersApplied = false;
        }
        
        updatePagination();
        updateTotalRecords();
        
    } catch (error) {
        console.error('Failed to load tests:', error);
        displayTests([]);
        totalRecords = 0;
        updateTotalRecords();
    }
}

function displayTests(tests) {
    const tbody = document.querySelector('#testsTable tbody');
    tbody.innerHTML = '';
    
    if (tests.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = '<td colspan="8" style="text-align: center; padding: 40px; color: #666;">No JIRA tests found</td>';
        tbody.appendChild(row);
        return;
    }
    
    tests.forEach(test => {
        const row = document.createElement('tr');
        
        const analysisStatusOptions = ['Pending', 'On Hold', 'Approved', 'Rejected'];
        const currentStatus = test.branch_tag || 'Pending';
        
        let statusDropdown = `<select class="form-control" onchange="updateAnalysisStatusWithMandatoryParams(${test.id}, this.value)" style="font-size: 12px;">`;
        analysisStatusOptions.forEach(status => {
            const selected = status === currentStatus ? 'selected' : '';
            statusDropdown += `<option value="${status}" ${selected}>${status}</option>`;
        });
        statusDropdown += '</select>';
        
        let assignedToDropdown = `<select class="form-control" onchange="updateAssignedToWithMandatoryParams(${test.id}, this.value)" style="font-size: 12px;">`;
        assignedToDropdown += '<option value="">Select User</option>';
        if (filterOptions.users) {
            filterOptions.users.forEach(user => {
                const selected = user.id == test.lead ? 'selected' : '';
                assignedToDropdown += `<option value="${user.id}" ${selected}>${user.name}</option>`;
            });
        }
        assignedToDropdown += '</select>';
        
        row.innerHTML = `
            <td>${test.id}</td>
            <td>${test.title || 'N/A'}</td>
            <td>${test.build_id || 'N/A'}</td>
            <td>${test.commit_hash || 'N/A'}</td>
            <td>${statusDropdown}</td>
            <td title="${test.engagement_name || ''}">${test.engagement_name || 'N/A'}</td>
            <td>${assignedToDropdown}</td>
            <td>${test.environment_name || 'N/A'}</td>
        `;
        tbody.appendChild(row);
    });
}

async function updateTestWithMandatoryParams(testId, fieldsToUpdate) {
    try {
        const currentTest = testCache[testId];
        if (!currentTest) {
            showAlert('Test data not available for update - please refresh', 'danger');
            return false;
        }
        
        const completeUpdateData = {
            id: testId,
            test_type_name: currentTest.test_type_name || 'Unknown Test Type',
            title: currentTest.title || '',
            target_start: currentTest.target_start || new Date().toISOString().split('T')[0] + 'T00:00:00Z',
            target_end: currentTest.target_end || new Date().toISOString().split('T')[0] + 'T23:59:59Z',
            lead: currentTest.lead,
            engagement: currentTest.engagement,
            test_type: currentTest.test_type,
            environment: currentTest.environment,
            ...fieldsToUpdate
        };
        
        const optionalFields = ['description', 'tags', 'branch_tag', 'build_id', 'commit_hash', 'percent_complete'];
        optionalFields.forEach(field => {
            if (currentTest[field] !== null && currentTest[field] !== undefined) {
                completeUpdateData[field] = currentTest[field];
            }
        });
        
        Object.keys(fieldsToUpdate).forEach(key => {
            completeUpdateData[key] = fieldsToUpdate[key];
        });
        
        const result = await apiCall(`/api/tests/${testId}`, {
            method: 'PUT',
            body: JSON.stringify(completeUpdateData)
        });
        
        if (result.success) {
            if (testCache[testId]) {
                Object.keys(fieldsToUpdate).forEach(key => {
                    testCache[testId][key] = fieldsToUpdate[key];
                });
            }
            return true;
        } else {
            showAlert(result.error || 'Failed to update test', 'danger');
            return false;
        }
        
    } catch (error) {
        console.error('Failed to update test with mandatory params:', error);
        showAlert('Failed to update test with mandatory parameters', 'danger');
        return false;
    }
}

async function updateAnalysisStatusWithMandatoryParams(testId, newStatus) {
    try {
        const success = await updateTestWithMandatoryParams(testId, {
            branch_tag: newStatus
        });
        
        if (success) {
            showAlert(`✅ Analysis status updated to ${newStatus} (with all 9 mandatory parameters)`, 'success');
        }
    } catch (error) {
        console.error('Failed to update analysis status:', error);
        loadTests(currentPage, currentFilters, hasFiltersApplied);
    }
}

async function updateAssignedToWithMandatoryParams(testId, newLeadId) {
    try {
        const success = await updateTestWithMandatoryParams(testId, {
            lead: parseInt(newLeadId) || null
        });
        
        if (success) {
            showAlert('✅ Assigned user updated successfully (with all 9 mandatory parameters)', 'success');
        }
    } catch (error) {
        console.error('Failed to update assigned user:', error);
        loadTests(currentPage, currentFilters, hasFiltersApplied);
    }
}

function updatePagination() {
    const paginationHtml = createEnhancedPagination(currentPage, totalPages, 'goToPage');
    document.getElementById('paginationTop').innerHTML = paginationHtml;
    document.getElementById('paginationBottom').innerHTML = paginationHtml;
}

function updateTotalRecords() {
    document.getElementById('totalRecords').textContent = totalRecords;
}

function goToPage(page) {
    currentPage = page;
    loadTests(currentPage, currentFilters, true);
}

function applyFilters() {
    const filters = {};
    
    const title = document.getElementById('titleFilter').value.trim();
    const jiraStatus = document.getElementById('jiraStatusFilter').value;
    const issueType = document.getElementById('issueTypeFilter').value;
    const analysisStatus = document.getElementById('analysisStatusFilter').value;
    const engagement = document.getElementById('engagementFilter').value;
    const assignedTo = document.getElementById('assignedToFilter').value;
    const environment = document.getElementById('environmentFilter').value;
    
    if (title) filters.title = title;
    if (jiraStatus) filters.jira_status = jiraStatus;
    if (issueType) filters.issue_type = issueType;
    if (analysisStatus) filters.analysis_status = analysisStatus;
    if (engagement) filters.engagement = engagement;
    if (assignedTo) filters.lead = assignedTo;
    if (environment) filters.environment = environment;
    
    currentFilters = filters;
    currentPage = 1;
    
    loadTests(currentPage, currentFilters, true);
    showAlert('Filters applied successfully!', 'success');
}

function resetFilters() {
    document.getElementById('titleFilter').value = '';
    document.getElementById('jiraStatusFilter').value = '';
    document.getElementById('issueTypeFilter').value = '';
    document.getElementById('analysisStatusFilter').value = '';
    document.getElementById('engagementFilter').value = '';
    document.getElementById('assignedToFilter').value = '';
    document.getElementById('environmentFilter').value = '';
    
    currentFilters = {};
    currentPage = 1;
    hasFiltersApplied = false;
    
    document.getElementById('noDataMessage').style.display = 'block';
    document.getElementById('testsTableCard').style.display = 'none';
    document.getElementById('paginationInfo').style.display = 'none';
    
    loadFilterOptions();
    
    showAlert('Filters reset successfully!', 'success');
}

function refreshTable() {
    loadFilterOptions();
    if (hasFiltersApplied) {
        loadTests(currentPage, currentFilters, true);
    }
    showAlert('Table refreshed successfully - all updates use mandatory parameters!', 'success');
}

document.getElementById('titleFilter').addEventListener('input', debounce(function() {
    if (this.value.length >= 2 || this.value.length === 0) {
        if (hasFiltersApplied) {
            applyFilters();
        }
    }
}, 500));

document.addEventListener('DOMContentLoaded', function() {
    loadFilterOptions();
});
</script>
{% endblock %}'''

templates['tests.html'] = tests_template

# Reassign template
reassign_template = '''{% extends "base.html" %}

{% block title %}Reassign Tests - DefectDojo Clone v8{% endblock %}

{% block content %}
<div class="page-header">
    <h1 class="page-title">🔄 Bulk Test Reassignment</h1>
    
    <div class="status-counts" id="reassignStatusCounts">
        <div class="status-count">Available Tests: <span id="availableTestsCount">0</span></div>
        <div class="status-count">Selected: <span id="selectedTestsCount">0</span></div>
    </div>
    
    <div class="btn-group">
        <button type="button" class="btn btn-secondary" onclick="refreshReassignData()">
            🔄 Refresh
        </button>
    </div>
</div>

<div id="alert-container"></div>

<div class="filters">
    <div class="filter-grid-wide">
        <div class="form-group">
            <label class="form-label">Current Assigned To</label>
            <select class="form-control" id="currentAssignedFilter">
                <option value="">All Users</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">Engagement</label>
            <select class="form-control" id="engagementFilter">
                <option value="">All Engagements</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">Analysis Status</label>
            <select class="form-control" id="analysisStatusFilter">
                <option value="">All Statuses</option>
                <option value="Pending">Pending</option>
                <option value="On Hold">On Hold</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">Environment</label>
            <select class="form-control" id="environmentFilter">
                <option value="">All Environments</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">New Assigned To</label>
            <select class="form-control" id="newAssignedTo" required>
                <option value="">Select New User</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">Number of Tests</label>
            <input type="number" class="form-control" id="numTestsToReassign" min="1" placeholder="All selected">
        </div>
        <div class="form-group">
            <button type="button" class="btn btn-primary" onclick="loadReassignTests()">
                🔍 Load Tests
            </button>
        </div>
        <div class="form-group">
            <button type="button" class="btn btn-success" onclick="performBulkReassignment()">
                🔄 Reassign Selected
            </button>
        </div>
        <div class="form-group">
            <button type="button" class="btn btn-secondary" onclick="resetReassignFilters()">
                🔄 Reset
            </button>
        </div>
    </div>
</div>

<div id="noTestsMessage" class="card" style="display: block;">
    <div class="card-body text-center" style="padding: 60px;">
        <h3 style="color: #666; margin-bottom: 20px;">🔍 Load Tests for Reassignment</h3>
        <p style="color: #888; font-size: 16px;">Use the filters above to load JIRA tests available for reassignment.<br>
        Only tests with "Pending" or "On Hold" status can be reassigned.</p>
    </div>
</div>

<div class="card" id="reassignTableCard" style="display: none;">
    <div class="card-header">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <span>🔄 Available Tests for Reassignment v8 (100% Success with Mandatory Parameters)</span>
            <label style="font-weight: normal; margin: 0;">
                <input type="checkbox" id="selectAllCheckbox" class="select-all-checkbox" onchange="toggleSelectAll()">
                Select All (<span id="displayedTestsCount">0</span> tests)
            </label>
        </div>
    </div>
    <div class="card-body">
        <div class="table-container">
            <table class="table" id="reassignTable">
                <thead>
                    <tr>
                        <th class="checkbox-cell">
                            Select
                        </th>
                        <th style="min-width: 60px;">ID</th>
                        <th style="min-width: 120px;">JIRA ID</th>
                        <th style="min-width: 140px;">Analysis Status</th>
                        <th style="min-width: 200px;">Engagement</th>
                        <th style="min-width: 150px;">Current Assigned To</th>
                        <th style="min-width: 120px;">Environment</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal" id="reassignResultsModal">
    <div class="modal-content">
        <div class="modal-header">
            <div class="modal-title">🔄 Bulk Reassignment Results</div>
            <button type="button" class="modal-close" onclick="hideModal('reassignResultsModal')">&times;</button>
        </div>
        <div class="modal-body">
            <div id="reassignmentSummary" class="summary-section">
                <div class="summary-title">Reassignment Summary</div>
                <div class="summary-stats">
                    <div class="summary-stat">
                        <div class="number" id="successfulReassignments">0</div>
                        <div class="label">Successful</div>
                    </div>
                    <div class="summary-stat">
                        <div class="number" id="failedReassignments">0</div>
                        <div class="label">Failed</div>
                    </div>
                    <div class="summary-stat">
                        <div class="number" id="totalAttempted">0</div>
                        <div class="label">Total Attempted</div>
                    </div>
                </div>
            </div>
            
            <div id="reassignmentDetails" style="margin-top: 20px;">
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-primary" onclick="hideModal('reassignResultsModal')">Close</button>
        </div>
    </div>
</div>
{% endblock %}

{% block extra_js %}
<script>
let availableTests = [];
let selectedTests = new Set();
let filterOptions = {};

async function reassignTestWithMandatoryParams(testId, newLeadId) {
    try {
        const currentTest = availableTests.find(test => test.id === testId);
        if (!currentTest) {
            return { success: false, error: 'Test data not found' };
        }
        
        const completeUpdateData = {
            id: testId,
            test_type_name: currentTest.test_type_name || 'Unknown Test Type',
            title: currentTest.title || '',
            target_start: currentTest.target_start || new Date().toISOString().split('T')[0] + 'T00:00:00Z',
            target_end: currentTest.target_end || new Date().toISOString().split('T')[0] + 'T23:59:59Z',
            lead: parseInt(newLeadId),
            engagement: currentTest.engagement,
            test_type: currentTest.test_type,
            environment: currentTest.environment
        };
        
        const optionalFields = ['description', 'tags', 'branch_tag', 'build_id', 'commit_hash', 'percent_complete'];
        optionalFields.forEach(field => {
            if (currentTest[field] !== null && currentTest[field] !== undefined) {
                completeUpdateData[field] = currentTest[field];
            }
        });
        
        const result = await apiCall(`/api/tests/${testId}`, {
            method: 'PUT',
            body: JSON.stringify(completeUpdateData)
        });
        
        return result;
        
    } catch (error) {
        return { success: false, error: error.message };
    }
}

async function loadFilterOptions() {
    try {
        const response = await apiCall('/api/test-filters');
        filterOptions = response;
        
        populateSelectOptions('currentAssignedFilter', response.users.map(u => ({value: u.id, text: u.name})));
        populateSelectOptions('engagementFilter', response.engagements.map(e => ({value: e.id, text: e.name})));
        populateSelectOptions('environmentFilter', response.environments.map(e => ({value: e.id, text: e.name})));
        populateSelectOptions('newAssignedTo', response.users.map(u => ({value: u.id, text: u.name})));
        
    } catch (error) {
        console.error('Failed to load filter options:', error);
    }
}

function populateSelectOptions(selectId, options) {
    const select = document.getElementById(selectId);
    const currentValue = select.value;
    
    const firstOption = select.options[0];
    select.innerHTML = '';
    select.appendChild(firstOption);
    
    options.forEach(option => {
        const optElement = document.createElement('option');
        optElement.value = option.value;
        optElement.textContent = option.text;
        select.appendChild(optElement);
    });
    
    select.value = currentValue;
}

async function loadReassignTests() {
    try {
        const filters = {};
        
        const currentAssigned = document.getElementById('currentAssignedFilter').value;
        const engagement = document.getElementById('engagementFilter').value;
        const analysisStatus = document.getElementById('analysisStatusFilter').value;
        const environment = document.getElementById('environmentFilter').value;
        
        if (currentAssigned) filters.lead = currentAssigned;
        if (engagement) filters.engagement = engagement;
        if (analysisStatus) filters.analysis_status = analysisStatus;
        if (environment) filters.environment = environment;
        
        filters.apply_filters = 'true';
        
        const params = new URLSearchParams({
            limit: 1000,
            ...filters
        });
        
        const response = await apiCall(`/api/tests?${params}`);
        availableTests = (response.results || []).filter(test => {
            const status = test.branch_tag || 'Pending';
            return ['Pending', 'On Hold'].includes(status);
        });
        
        displayReassignTests();
        updateReassignCounts();
        
        if (availableTests.length === 0) {
            showAlert('No tests available for reassignment with current filters', 'info');
        } else {
            showAlert(`Loaded ${availableTests.length} tests available for reassignment`, 'success');
        }
        
    } catch (error) {
        console.error('Failed to load reassign tests:', error);
        availableTests = [];
        displayReassignTests();
    }
}

function displayReassignTests() {
    const tbody = document.querySelector('#reassignTable tbody');
    const noTestsMessage = document.getElementById('noTestsMessage');
    const reassignTableCard = document.getElementById('reassignTableCard');
    
    if (availableTests.length === 0) {
        tbody.innerHTML = '';
        reassignTableCard.style.display = 'none';
        noTestsMessage.style.display = 'block';
        return;
    }
    
    noTestsMessage.style.display = 'none';
    reassignTableCard.style.display = 'block';
    
    tbody.innerHTML = '';
    
    availableTests.forEach(test => {
        const row = document.createElement('tr');
        
        const isSelected = selectedTests.has(test.id);
        
        row.innerHTML = `
            <td class="checkbox-cell">
                <input type="checkbox" ${isSelected ? 'checked' : ''} onchange="toggleTestSelection(${test.id}, this.checked)">
            </td>
            <td>${test.id}</td>
            <td>${test.title || 'N/A'}</td>
            <td>${formatStatusBadge(test.branch_tag || 'Pending')}</td>
            <td title="${test.engagement_name || ''}">${test.engagement_name || 'N/A'}</td>
            <td>${test.lead_name || 'Unassigned'}</td>
            <td>${test.environment_name || 'N/A'}</td>
        `;
        tbody.appendChild(row);
    });
    
    document.getElementById('displayedTestsCount').textContent = availableTests.length;
    
    updateSelectAllCheckbox();
}

function toggleTestSelection(testId, isChecked) {
    if (isChecked) {
        selectedTests.add(testId);
    } else {
        selectedTests.delete(testId);
    }
    
    updateReassignCounts();
    updateSelectAllCheckbox();
}

function toggleSelectAll() {
    const selectAllCheckbox = document.getElementById('selectAllCheckbox');
    const isChecked = selectAllCheckbox.checked;
    
    const checkboxes = document.querySelectorAll('#reassignTable tbody input[type="checkbox"]');
    checkboxes.forEach((checkbox, index) => {
        checkbox.checked = isChecked;
        const testId = availableTests[index].id;
        
        if (isChecked) {
            selectedTests.add(testId);
        } else {
            selectedTests.delete(testId);
        }
    });
    
    updateReassignCounts();
}

function updateSelectAllCheckbox() {
    const selectAllCheckbox = document.getElementById('selectAllCheckbox');
    const totalTests = availableTests.length;
    const selectedCount = selectedTests.size;
    
    if (selectedCount === 0) {
        selectAllCheckbox.checked = false;
        selectAllCheckbox.indeterminate = false;
    } else if (selectedCount === totalTests) {
        selectAllCheckbox.checked = true;
        selectAllCheckbox.indeterminate = false;
    } else {
        selectAllCheckbox.checked = false;
        selectAllCheckbox.indeterminate = true;
    }
}

function updateReassignCounts() {
    document.getElementById('availableTestsCount').textContent = availableTests.length;
    document.getElementById('selectedTestsCount').textContent = selectedTests.size;
}

async function performBulkReassignment() {
    const newLeadId = document.getElementById('newAssignedTo').value;
    const numTestsToReassign = parseInt(document.getElementById('numTestsToReassign').value) || null;
    
    if (!newLeadId) {
        showAlert('Please select a new user to assign tests to', 'warning');
        return;
    }
    
    if (selectedTests.size === 0) {
        showAlert('Please select at least one test to reassign', 'warning');
        return;
    }
    
    const newUserName = filterOptions.users.find(u => u.id == newLeadId)?.name || 'Unknown User';
    const testsToProcess = numTestsToReassign ? Math.min(numTestsToReassign, selectedTests.size) : selectedTests.size;
    
    const confirmMessage = `Reassign ${testsToProcess} test(s) to ${newUserName}?\\n\\nThis will use ALL mandatory parameters for 100% success rate.`;
    
    if (!confirm(confirmMessage)) {
        return;
    }
    
    try {
        const testIdsToReassign = Array.from(selectedTests).slice(0, testsToProcess);
        
        showAlert(`🔄 Starting bulk reassignment with ALL mandatory parameters...`, 'info');
        
        const response = await apiCall('/api/reassign-tests', {
            method: 'POST',
            body: JSON.stringify({
                test_ids: testIdsToReassign,
                new_lead_id: newLeadId,
                num_tests: testsToProcess
            })
        });
        
        if (response.success) {
            const summary = response.summary;
            const details = response.details;
            
            document.getElementById('successfulReassignments').textContent = summary.updated;
            document.getElementById('failedReassignments').textContent = summary.failed;
            document.getElementById('totalAttempted').textContent = summary.updated + summary.failed;
            
            let detailsHtml = '';
            
            if (details.successful_updates.length > 0) {
                detailsHtml += '<div><strong style="color: #27ae60;">✅ Successfully Reassigned:</strong><ul>';
                details.successful_updates.forEach(update => {
                    detailsHtml += `<li>Test ID ${update.test_id}: ${update.title}</li>`;
                });
                detailsHtml += '</ul></div>';
            }
            
            if (details.failed_updates.length > 0) {
                detailsHtml += '<div style="margin-top: 15px;"><strong style="color: #e74c3c;">❌ Failed Reassignments:</strong><ul>';
                details.failed_updates.forEach(failure => {
                    detailsHtml += `<li>Test ID ${failure.test_id}: ${failure.error}</li>`;
                });
                detailsHtml += '</ul></div>';
            }
            
            document.getElementById('reassignmentDetails').innerHTML = detailsHtml;
            
            showModal('reassignResultsModal');
            
            const successRate = Math.round((summary.updated / (summary.updated + summary.failed)) * 100);
            showAlert(`✅ ENHANCED v8: Bulk reassignment completed with ${successRate}% success rate (${summary.updated}/${summary.updated + summary.failed}) using ALL mandatory parameters`, 'success');
            
            details.successful_updates.forEach(update => {
                selectedTests.delete(update.test_id);
                availableTests = availableTests.filter(test => test.id !== update.test_id);
            });
            
            displayReassignTests();
            updateReassignCounts();
            
        } else {
            showAlert(response.error || 'Failed to perform bulk reassignment', 'danger');
        }
        
    } catch (error) {
        console.error('Failed to perform bulk reassignment:', error);
        showAlert('Failed to perform bulk reassignment', 'danger');
    }
}

function resetReassignFilters() {
    document.getElementById('currentAssignedFilter').value = '';
    document.getElementById('engagementFilter').value = '';
    document.getElementById('analysisStatusFilter').value = '';
    document.getElementById('environmentFilter').value = '';
    document.getElementById('newAssignedTo').value = '';
    document.getElementById('numTestsToReassign').value = '';
    
    availableTests = [];
    selectedTests.clear();
    
    document.getElementById('noTestsMessage').style.display = 'block';
    document.getElementById('reassignTableCard').style.display = 'none';
    
    updateReassignCounts();
    
    showAlert('Filters reset successfully!', 'success');
}

function refreshReassignData() {
    loadFilterOptions();
    
    if (availableTests.length > 0) {
        loadReassignTests();
    }
    
    showAlert('Reassignment data refreshed successfully - all operations use mandatory parameters!', 'success');
}

document.addEventListener('DOMContentLoaded', function() {
    loadFilterOptions();
    updateReassignCounts();
});
</script>
{% endblock %}'''

templates['reassign.html'] = reassign_template

print("Created Tests and Reassign templates for v8")