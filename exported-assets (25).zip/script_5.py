# Create remaining templates - Engagements, Tests, Reassign (same as before but with v8 branding)

# Engagements template - same as before
engagements_template = '''{% extends "base.html" %}

{% block title %}Engagements - DefectDojo Clone v8{% endblock %}

{% block content %}
<div class="page-header">
    <h1 class="page-title">Engagements</h1>
    
    <div class="status-counts" id="statusCounts">
        <div class="status-count">Not Started: <span id="notStartedCount">0</span></div>
        <div class="status-count">In Progress: <span id="inProgressCount">0</span></div>
        <div class="status-count">On Hold: <span id="onHoldCount">0</span></div>
    </div>
    
    <div class="btn-group">
        <button type="button" class="btn btn-primary" onclick="openCreateModal()">
            ➕ New Engagement
        </button>
        <button type="button" class="btn btn-secondary" onclick="refreshTable()">
            🔄 Refresh
        </button>
    </div>
</div>

<div id="alert-container"></div>

<div class="filters">
    <div class="filter-grid-wide">
        <div class="form-group">
            <label class="form-label">Created From</label>
            <input type="date" class="form-control" id="createdFromFilter">
        </div>
        <div class="form-group">
            <label class="form-label">Created To</label>
            <input type="date" class="form-control" id="createdToFilter">
        </div>
        <div class="form-group">
            <label class="form-label">Name</label>
            <input type="text" class="form-control" id="nameFilter" placeholder="Search by name...">
        </div>
        <div class="form-group">
            <label class="form-label">AppSec ETA From</label>
            <input type="date" class="form-control" id="appsecEtaFromFilter">
        </div>
        <div class="form-group">
            <label class="form-label">AppSec ETA To</label>
            <input type="date" class="form-control" id="appsecEtaToFilter">
        </div>
        <div class="form-group">
            <label class="form-label">RM ETA From</label>
            <input type="date" class="form-control" id="rmEtaFromFilter">
        </div>
        <div class="form-group">
            <label class="form-label">RM ETA To</label>
            <input type="date" class="form-control" id="rmEtaToFilter">
        </div>
        <div class="form-group">
            <label class="form-label">Analysis Status</label>
            <select class="form-control" id="analysisStatusFilter">
                <option value="">All Statuses</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">Task Type</label>
            <select class="form-control" id="taskTypeFilter">
                <option value="">All Task Types</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">Mentor Review Status</label>
            <select class="form-control" id="mentorReviewFilter">
                <option value="">All Reviews</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">Lead Review Status</label>
            <select class="form-control" id="leadReviewFilter">
                <option value="">All Reviews</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">Assigned To</label>
            <select class="form-control" id="assignedToFilter">
                <option value="">All Users</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">Product</label>
            <select class="form-control" id="productFilter">
                <option value="">All Products</option>
            </select>
        </div>
        <div class="form-group">
            <button type="button" class="btn btn-primary" onclick="applyFilters()">
                🔍 Go
            </button>
        </div>
        <div class="form-group">
            <button type="button" class="btn btn-warning" onclick="fetchAllTestCounts()" id="fetchTestsBtn">
                📊 Fetch ALL Tests
            </button>
        </div>
        <div class="form-group">
            <button type="button" class="btn btn-secondary" onclick="resetFilters()">
                🔄 Reset
            </button>
        </div>
    </div>
</div>

<div class="pagination-info">
    <div class="total-records">
        Total Records: <span id="totalRecords">0</span>
    </div>
    <div class="pagination-controls" id="paginationTop">
    </div>
</div>

<div class="card">
    <div class="card-header">
        🤝 Engagements List - Enhanced v8 with Close Feature
    </div>
    <div class="card-body">
        <div class="table-container">
            <table class="table" id="engagementsTable">
                <thead>
                    <tr>
                        <th style="min-width: 60px;">ID</th>
                        <th style="min-width: 100px;">Created</th>
                        <th style="min-width: 80px;">Aging</th>
                        <th style="min-width: 120px;">Name</th>
                        <!-- JIRA Test Counts Header with Sub-columns -->
                        <th colspan="7" class="jira-header" style="text-align: center; min-width: 280px;">
                            📊 Jira Test Counts (Browser Persistent Cache)
                        </th>
                        <th style="min-width: 100px;">AppSec ETA</th>
                        <th style="min-width: 100px;">RM ETA</th>
                        <th style="min-width: 120px;">Analysis Status</th>
                        <th style="min-width: 100px;">Task Type</th>
                        <th style="min-width: 140px;">Mentor Review Analysis</th>
                        <th style="min-width: 120px;">Lead Review Status</th>
                        <th style="min-width: 100px;">Assigned To</th>
                        <th style="min-width: 100px;">Product</th>
                        <th style="min-width: 60px;">IR</th>
                        <th style="min-width: 150px;">Last Updated</th>
                        <th style="min-width: 120px;">Actions</th>
                    </tr>
                    <tr>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th class="jira-subheader" title="Total JIRA tests">T</th>
                        <th class="jira-subheader" title="Completed (Approved/Rejected)">C</th>
                        <th class="jira-subheader" title="Pending (Pending/On Hold)">P</th>
                        <th class="jira-subheader" title="Security tests">S</th>
                        <th class="jira-subheader" title="Functional tests">F</th>
                        <th class="jira-subheader" title="Doable (Done/Ready for Testing/Ready for QA)">D</th>
                        <th class="jira-subheader" title="Not Doable (triggers On Hold status)">N</th>
                        <th></th>
                        <th title="Highlights in RED if date is TODAY">RM ETA 🔴</th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
        
        <div class="pagination" id="paginationBottom">
        </div>
    </div>
</div>

<!-- Engagement Modal with Created by field -->
<div class="modal" id="engagementModal">
    <div class="modal-content">
        <div class="modal-header">
            <div class="modal-title" id="modalTitle">Create New Engagement</div>
            <button type="button" class="modal-close" onclick="hideModal('engagementModal')">&times;</button>
        </div>
        <form id="engagementForm">
            <div class="modal-body">
                <input type="hidden" id="engagementId">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Tags</label>
                        <input type="text" class="form-control" id="tags" value="pci" placeholder="Comma separated tags">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Status</label>
                        <select class="form-control" id="status">
                            <option value="Not Started" selected>Not Started</option>
                            <option value="In Progress">In Progress</option>
                            <option value="On Hold">On Hold</option>
                        </select>
                    </div>
                    <div class="form-group form-grid-full">
                        <label class="form-label">Name *</label>
                        <input type="text" class="form-control" id="name" required>
                    </div>
                    <div class="form-group form-grid-full">
                        <label class="form-label">Created by</label>
                        <input type="text" class="form-control" id="createdBy" placeholder="Enter who created this engagement">
                    </div>
                    <div class="form-group">
                        <label class="form-label">AppSec ETA</label>
                        <input type="date" class="form-control" id="targetStart">
                    </div>
                    <div class="form-group">
                        <label class="form-label">RM ETA</label>
                        <input type="date" class="form-control" id="targetEnd">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Assigned To</label>
                        <select class="form-control" id="lead">
                            <option value="">Select User</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Product *</label>
                        <select class="form-control" id="product" required>
                            <option value="">Select Product</option>
                        </select>
                    </div>
                    
                    <div class="form-group edit-only" style="display: none;">
                        <label class="form-label">IR</label>
                        <input type="text" class="form-control" id="version" placeholder="Enter IR version">
                    </div>
                    <div class="form-group edit-only" style="display: none;">
                        <label class="form-label">Mentor Review Status</label>
                        <select class="form-control" id="buildId">
                            <option value="Not Started" selected>Not Started</option>
                            <option value="In Progress">In Progress</option>
                            <option value="On Hold">On Hold</option>
                            <option value="Completed">Completed</option>
                        </select>
                    </div>
                    <div class="form-group edit-only" style="display: none;">
                        <label class="form-label">Lead Review Status</label>
                        <select class="form-control" id="commitHash">
                            <option value="Not Started" selected>Not Started</option>
                            <option value="Approved">Approved</option>
                            <option value="Approved with Exception">Approved with Exception</option>
                            <option value="Rejected">Rejected</option>
                            <option value="Repatched">Repatched</option>
                            <option value="On Hold">On Hold</option>
                        </select>
                    </div>
                    <div class="form-group form-grid-full edit-only" style="display: none;">
                        <label class="form-label">Comment</label>
                        <textarea class="form-control" id="description" rows="4" placeholder="Enter comments or description"></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="hideModal('engagementModal')">Cancel</button>
                <button type="submit" class="btn btn-primary">Save</button>
                <button type="button" class="btn btn-info edit-only" style="display: none;" onclick="openChangelogsModal()">
                    📋 Changelogs
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Changelogs Importer Modal -->
<div class="modal" id="changelogsModal">
    <div class="modal-content">
        <div class="modal-header">
            <div class="modal-title">Changelogs Importer</div>
            <button type="button" class="modal-close" onclick="hideModal('changelogsModal')">&times;</button>
        </div>
        <div class="modal-body">
            <div class="form-grid-full">
                <div class="form-group">
                    <label class="form-label">Changelog Text</label>
                    <textarea class="form-control" id="changelogText" rows="8" placeholder="Paste your changelog text here. JIRA IDs will be extracted automatically."></textarea>
                </div>
                
                <div class="form-group">
                    <button type="button" class="btn btn-warning" onclick="fetchJiraIds()">
                        🔍 Fetch JIRA
                    </button>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Extracted JIRA IDs</label>
                    <textarea class="form-control" id="extractedJiras" rows="4" readonly placeholder="Comma-separated unique JIRA IDs will appear here..."></textarea>
                    <div style="margin-top: 5px;">
                        <small id="jiraCount" class="text-secondary">Count: 0</small>
                    </div>
                </div>
                
                <div class="form-group">
                    <button type="button" class="btn btn-success" onclick="createJiraTests()" disabled id="addTestsBtn">
                        ➕ Add Tests
                    </button>
                </div>
                
                <div id="creationSummary" class="summary-section" style="display: none;">
                    <div class="summary-title">Test Creation Summary</div>
                    <div class="summary-stats">
                        <div class="summary-stat">
                            <div class="number" id="createdCount">0</div>
                            <div class="label">Created</div>
                        </div>
                        <div class="summary-stat">
                            <div class="number" id="skippedCount">0</div>
                            <div class="label">Skipped</div>
                        </div>
                        <div class="summary-stat">
                            <div class="number" id="errorCount">0</div>
                            <div class="label">Errors</div>
                        </div>
                    </div>
                    <div id="detailsList" style="margin-top: 15px;"></div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="hideModal('changelogsModal')">Close</button>
        </div>
    </div>
</div>
{% endblock %}

{% block extra_js %}
<script>
let currentPage = 1;
let totalPages = 1;
let totalRecords = 0;
let currentFilters = {};
let filterOptions = {};
let currentEngagementId = null;
let currentEngagements = [];

// ENHANCED: PERSISTENT JIRA COUNTS - Browser Restart Persistent
let persistentJiraCounts = {};

function savePersistentCountsToStorage() {
    try {
        const dataToStore = {
            counts: persistentJiraCounts,
            timestamp: new Date().getTime(),
            version: '2.0'
        };
        localStorage.setItem('defectdojo_jira_counts_v2', JSON.stringify(dataToStore));
        console.log('Saved JIRA counts to localStorage');
    } catch (e) {
        console.log('LocalStorage not available, using memory cache only');
    }
}

function loadPersistentCountsFromStorage() {
    try {
        const stored = localStorage.getItem('defectdojo_jira_counts_v2');
        
        if (stored) {
            const data = JSON.parse(stored);
            const age = Date.now() - data.timestamp;
            const maxAge = 24 * 60 * 60 * 1000; // 24 hours
            
            if (age < maxAge && data.version === '2.0') {
                persistentJiraCounts = data.counts || {};
                console.log(`Loaded ${Object.keys(persistentJiraCounts).length} JIRA counts from localStorage`);
                return true;
            } else {
                localStorage.removeItem('defectdojo_jira_counts_v2');
            }
        }
    } catch (e) {
        console.log('Could not load from localStorage, starting fresh');
        persistentJiraCounts = {};
    }
    return false;
}

const debouncedLoadEngagements = debounce(loadEngagements, 300);

async function loadFilterOptions() {
    try {
        const response = await apiCall('/api/engagement-filters');
        filterOptions = response;
        
        populateSelectOptions('analysisStatusFilter', response.analysis_statuses.map(s => ({value: s, text: s})));
        populateSelectOptions('taskTypeFilter', response.task_types.map(s => ({value: s, text: s})));
        populateSelectOptions('mentorReviewFilter', response.mentor_reviews.map(s => ({value: s, text: s})));
        populateSelectOptions('leadReviewFilter', response.lead_reviews.map(s => ({value: s, text: s})));
        populateSelectOptions('assignedToFilter', response.users.map(u => ({value: u.id, text: u.name})));
        populateSelectOptions('productFilter', response.products.map(p => ({value: p.id, text: p.name})));
        
        populateSelectOptions('lead', response.users.map(u => ({value: u.id, text: u.name})));
        populateSelectOptions('product', response.products.map(p => ({value: p.id, text: p.name})));
        
    } catch (error) {
        console.error('Failed to load filter options:', error);
    }
}

function populateSelectOptions(selectId, options) {
    const select = document.getElementById(selectId);
    const currentValue = select.value;
    
    const firstOption = select.options[0];
    select.innerHTML = '';
    select.appendChild(firstOption);
    
    options.forEach(option => {
        const optElement = document.createElement('option');
        optElement.value = option.value;
        optElement.textContent = option.text;
        select.appendChild(optElement);
    });
    
    select.value = currentValue;
}

function updateStatusCounts(counts) {
    document.getElementById('notStartedCount').textContent = counts['Not Started'] || 0;
    document.getElementById('inProgressCount').textContent = counts['In Progress'] || 0;
    document.getElementById('onHoldCount').textContent = counts['On Hold'] || 0;
}

async function loadEngagements(page = 1, filters = {}) {
    try {
        const params = new URLSearchParams({
            page: page,
            ...filters
        });
        
        const response = await apiCall(`/api/engagements?${params}`);
        currentEngagements = response.results || [];
        displayEngagements(currentEngagements);
        
        currentPage = response.page || 1;
        totalPages = response.total_pages || 1;
        totalRecords = response.count || 0;
        
        if (response.status_counts) {
            updateStatusCounts(response.status_counts);
        }
        
        displayCachedCounts();
        updateFetchTestsButton();
        updatePagination();
        updateTotalRecords();
        
    } catch (error) {
        console.error('Failed to load engagements:', error);
        displayEngagements([]);
        totalRecords = 0;
        updateTotalRecords();
        updateStatusCounts({'Not Started': 0, 'In Progress': 0, 'On Hold': 0});
    }
}

function displayCachedCounts() {
    currentEngagements.forEach((engagement, index) => {
        const cachedCounts = persistentJiraCounts[engagement.id];
        if (cachedCounts && cachedCounts.fetched) {
            engagement.test_counts = cachedCounts;
            
            const tbody = document.querySelector('#engagementsTable tbody');
            const row = tbody.children[index];
            if (row && row.children.length >= 12) {
                const cells = row.children;
                
                cells[4].textContent = cachedCounts.T || '0';
                cells[4].classList.add('fetched');
                cells[5].textContent = cachedCounts.C || '0';
                cells[5].classList.add('fetched');
                cells[6].textContent = cachedCounts.P || '0';
                cells[6].classList.add('fetched');
                cells[7].textContent = cachedCounts.S || '0';
                cells[7].classList.add('fetched');
                cells[8].textContent = cachedCounts.F || '0';
                cells[8].classList.add('fetched');
                cells[9].textContent = cachedCounts.D || '0';
                cells[9].classList.add('fetched');
                cells[10].textContent = cachedCounts.N || '0';
                cells[10].classList.add('fetched');
            }
        }
    });
}

async function fetchAllTestCounts() {
    try {
        const fetchBtn = document.getElementById('fetchTestsBtn');
        const originalText = fetchBtn.textContent;
        fetchBtn.disabled = true;
        fetchBtn.textContent = '⏳ Fetching All Tests...';
        
        showAlert('Fetching test counts for ALL engagements across all pages...', 'info');
        
        const response = await apiCall('/api/fetch-engagement-test-counts', {
            method: 'POST',
            body: JSON.stringify({})
        });
        
        if (response.success) {
            updateTestCountsInCurrentView(response.test_counts);
            
            Object.keys(response.test_counts).forEach(engagementId => {
                persistentJiraCounts[engagementId] = {
                    ...response.test_counts[engagementId],
                    fetched: true,
                    timestamp: new Date().getTime()
                };
            });
            
            savePersistentCountsToStorage();
            
            const totalCount = Object.keys(response.test_counts).length;
            showAlert(`✅ SUCCESS: Test counts fetched and cached for ${totalCount} engagements (persists across browser restarts)`, 'success');
            
            console.log(`Fetched and cached counts for ${totalCount} engagements`);
        } else {
            showAlert(response.error || 'Failed to fetch test counts', 'danger');
        }
        
    } catch (error) {
        console.error('Failed to fetch all test counts:', error);
        showAlert('Failed to fetch test counts across all pages', 'danger');
    } finally {
        updateFetchTestsButton();
    }
}

function updateTestCountsInCurrentView(allTestCounts) {
    currentEngagements.forEach((engagement, index) => {
        const counts = allTestCounts[engagement.id];
        if (counts) {
            engagement.test_counts = counts;
            
            const tbody = document.querySelector('#engagementsTable tbody');
            const row = tbody.children[index];
            if (row && row.children.length >= 12) {
                const cells = row.children;
                
                cells[4].textContent = counts.T || '0';
                cells[4].classList.add('fetched');
                cells[5].textContent = counts.C || '0';
                cells[5].classList.add('fetched');
                cells[6].textContent = counts.P || '0';
                cells[6].classList.add('fetched');
                cells[7].textContent = counts.S || '0';
                cells[7].classList.add('fetched');
                cells[8].textContent = counts.F || '0';
                cells[8].classList.add('fetched');
                cells[9].textContent = counts.D || '0';
                cells[9].classList.add('fetched');
                cells[10].textContent = counts.N || '0';
                cells[10].classList.add('fetched');
                
                for (let i = 4; i <= 10; i++) {
                    cells[i].classList.remove('loading');
                }
            }
        }
    });
}

function updateFetchTestsButton() {
    const fetchBtn = document.getElementById('fetchTestsBtn');
    
    const totalCached = Object.keys(persistentJiraCounts).length;
    const hasAnyCached = totalCached > 0;
    
    fetchBtn.disabled = false;
    
    if (hasAnyCached) {
        fetchBtn.textContent = `🔄 Refresh ALL Tests (${totalCached} cached)`;
        fetchBtn.title = `Refresh test counts for ALL engagements. Currently ${totalCached} counts cached in browser`;
        fetchBtn.classList.add('btn-warning');
        fetchBtn.classList.remove('btn-secondary');
    } else {
        fetchBtn.textContent = '📊 Fetch ALL Tests';
        fetchBtn.title = 'Fetch test counts for ALL engagements across all pages (will be cached for 24 hours)';
        fetchBtn.classList.remove('btn-warning');
        fetchBtn.classList.add('btn-warning');
    }
}

function displayEngagements(engagements) {
    const tbody = document.querySelector('#engagementsTable tbody');
    tbody.innerHTML = '';
    
    if (engagements.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = '<td colspan="20" style="text-align: center; padding: 40px; color: #666;">No engagements found</td>';
        tbody.appendChild(row);
        return;
    }
    
    engagements.forEach(engagement => {
        const row = document.createElement('tr');
        
        const taskTypesHtml = (engagement.task_types || []).map(tag => 
            `<span class="task-type ${tag}">${tag}</span>`
        ).join(' ') || 'N/A';
        
        let testCounts = {'T': 0, 'C': 0, 'P': 0, 'S': 0, 'F': 0, 'D': 0, 'N': 0};
        let isFetched = false;
        
        if (persistentJiraCounts[engagement.id]) {
            testCounts = persistentJiraCounts[engagement.id];
            isFetched = persistentJiraCounts[engagement.id].fetched || false;
        }
        else if (engagement.test_counts) {
            testCounts = engagement.test_counts;
        }
        
        const fetchedClass = isFetched ? ' fetched' : '';
        
        const rmEtaDate = formatDate(engagement.target_end);
        const rmEtaIsToday = engagement.rm_eta_is_today;
        const rmEtaClass = rmEtaIsToday ? ' rm-eta-today' : '';
        
        row.innerHTML = `
            <td>${engagement.id}</td>
            <td>${formatDate(engagement.created)}</td>
            <td>${formatAging(engagement.aging)}</td>
            <td title="${engagement.name || ''}">${engagement.name || 'N/A'}</td>
            <td class="jira-count${fetchedClass}" title="Total JIRA tests">${testCounts.T}</td>
            <td class="jira-count${fetchedClass}" title="Completed (Approved/Rejected)">${testCounts.C}</td>
            <td class="jira-count${fetchedClass}" title="Pending (Pending/On Hold)">${testCounts.P}</td>
            <td class="jira-count${fetchedClass}" title="Security tests">${testCounts.S}</td>
            <td class="jira-count${fetchedClass}" title="Functional tests">${testCounts.F}</td>
            <td class="jira-count${fetchedClass}" title="Doable (Done/Ready for Testing/Ready for QA)">${testCounts.D}</td>
            <td class="jira-count${fetchedClass}" title="Not Doable (triggers On Hold status)">${testCounts.N}</td>
            <td>${formatDate(engagement.target_start)}</td>
            <td class="${rmEtaClass}">${rmEtaDate}${rmEtaIsToday ? ' ⚠️' : ''}</td>
            <td>${formatStatusBadge(engagement.status || 'Unknown')}</td>
            <td>${taskTypesHtml}</td>
            <td>${engagement.build_id || 'N/A'}</td>
            <td>${engagement.commit_hash || 'N/A'}</td>
            <td>${engagement.lead_name || engagement.lead || 'N/A'}</td>
            <td>${engagement.product_name || engagement.product || 'N/A'}</td>
            <td>${engagement.version || 'N/A'}</td>
            <td>${engagement.formatted_updated || 'N/A'}</td>
            <td>
                <button class="btn btn-small btn-primary" onclick="editEngagement(${engagement.id})" title="Edit">
                    ✏️
                </button>
                <button class="btn btn-small btn-warning" onclick="closeEngagement(${engagement.id})" title="Close">
                    ❌
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function updatePagination() {
    const paginationHtml = createEnhancedPagination(currentPage, totalPages, 'goToPage');
    document.getElementById('paginationTop').innerHTML = paginationHtml;
    document.getElementById('paginationBottom').innerHTML = paginationHtml;
}

function updateTotalRecords() {
    document.getElementById('totalRecords').textContent = totalRecords;
}

function goToPage(page) {
    currentPage = page;
    loadEngagements(currentPage, currentFilters);
}

function applyFilters() {
    const filters = {};
    
    const createdFrom = document.getElementById('createdFromFilter').value;
    const createdTo = document.getElementById('createdToFilter').value;
    const appsecEtaFrom = document.getElementById('appsecEtaFromFilter').value;
    const appsecEtaTo = document.getElementById('appsecEtaToFilter').value;
    const rmEtaFrom = document.getElementById('rmEtaFromFilter').value;
    const rmEtaTo = document.getElementById('rmEtaToFilter').value;
    
    const name = document.getElementById('nameFilter').value.trim();
    
    const analysisStatus = document.getElementById('analysisStatusFilter').value;
    const taskType = document.getElementById('taskTypeFilter').value;
    const mentorReview = document.getElementById('mentorReviewFilter').value;
    const leadReview = document.getElementById('leadReviewFilter').value;
    const assignedTo = document.getElementById('assignedToFilter').value;
    const product = document.getElementById('productFilter').value;
    
    if (createdFrom) filters.created_from = createdFrom;
    if (createdTo) filters.created_to = createdTo;
    if (name) filters.name = name;
    if (appsecEtaFrom) filters.appsec_eta_from = appsecEtaFrom;
    if (appsecEtaTo) filters.appsec_eta_to = appsecEtaTo;
    if (rmEtaFrom) filters.rm_eta_from = rmEtaFrom;
    if (rmEtaTo) filters.rm_eta_to = rmEtaTo;
    if (analysisStatus) filters.analysis_status = analysisStatus;
    if (taskType) filters.task_type = taskType;
    if (mentorReview) filters.mentor_review = mentorReview;
    if (leadReview) filters.lead_review = leadReview;
    if (assignedTo) filters.assigned_to = assignedTo;
    if (product) filters.product = product;
    
    currentFilters = filters;
    currentPage = 1;
    
    loadEngagements(currentPage, currentFilters);
    showAlert('Filters applied successfully!', 'success');
}

function resetFilters() {
    document.getElementById('createdFromFilter').value = '';
    document.getElementById('createdToFilter').value = '';
    document.getElementById('nameFilter').value = '';
    document.getElementById('appsecEtaFromFilter').value = '';
    document.getElementById('appsecEtaToFilter').value = '';
    document.getElementById('rmEtaFromFilter').value = '';
    document.getElementById('rmEtaToFilter').value = '';
    document.getElementById('analysisStatusFilter').value = '';
    document.getElementById('taskTypeFilter').value = '';
    document.getElementById('mentorReviewFilter').value = '';
    document.getElementById('leadReviewFilter').value = '';
    document.getElementById('assignedToFilter').value = '';
    document.getElementById('productFilter').value = '';
    
    currentFilters = {};
    currentPage = 1;
    
    loadEngagements(currentPage, currentFilters);
    showAlert('Filters reset successfully!', 'success');
}

function refreshTable() {
    loadFilterOptions();
    loadEngagements(currentPage, currentFilters);
    showAlert('Table refreshed successfully - cached counts preserved!', 'success');
}

function openCreateModal() {
    document.getElementById('modalTitle').textContent = 'Create New Engagement';
    document.getElementById('engagementForm').reset();
    document.getElementById('engagementId').value = '';
    currentEngagementId = null;
    
    document.querySelectorAll('.edit-only').forEach(field => {
        field.style.display = 'none';
    });
    
    const statusSelect = document.getElementById('status');
    statusSelect.innerHTML = `
        <option value="Not Started" selected>Not Started</option>
        <option value="In Progress">In Progress</option>
        <option value="On Hold">On Hold</option>
    `;
    
    document.getElementById('tags').value = 'pci';
    document.getElementById('status').value = 'Not Started';
    document.getElementById('targetStart').value = getCurrentDate();
    document.getElementById('targetEnd').value = getCurrentDate();
    
    showModal('engagementModal');
}

async function editEngagement(id) {
    try {
        const response = await apiCall(`/api/engagements/${id}`);
        
        if (response.error) {
            showAlert(response.error, 'danger');
            return;
        }
        
        document.getElementById('modalTitle').textContent = 'Edit Engagement';
        document.getElementById('engagementId').value = id;
        currentEngagementId = id;
        
        document.querySelectorAll('.edit-only').forEach(field => {
            field.style.display = 'flex';
        });
        
        const statusSelect = document.getElementById('status');
        statusSelect.innerHTML = `
            <option value="Not Started">Not Started</option>
            <option value="In Progress">In Progress</option>
            <option value="On Hold">On Hold</option>
        `;
        
        document.getElementById('tags').value = response.tags ? response.tags.join(', ') : 'pci';
        document.getElementById('name').value = response.name || '';
        document.getElementById('createdBy').value = response.reason || '';
        document.getElementById('status').value = response.status || 'Not Started';
        document.getElementById('targetStart').value = response.target_start || '';
        document.getElementById('targetEnd').value = response.target_end || '';
        document.getElementById('lead').value = response.lead || '';
        document.getElementById('product').value = response.product || '';
        document.getElementById('version').value = response.version || '';
        document.getElementById('description').value = response.description || '';
        document.getElementById('buildId').value = response.build_id || 'Not Started';
        document.getElementById('commitHash').value = response.commit_hash || 'Not Started';
        
        showModal('engagementModal');
        
    } catch (error) {
        console.error('Failed to load engagement:', error);
    }
}

async function closeEngagement(id) {
    if (!confirm('Are you sure you want to close this engagement?')) {
        return;
    }
    
    try {
        const result = await apiCall(`/api/engagements/${id}/close`, { method: 'POST' });
        if (result.success) {
            showAlert('Engagement closed successfully!', 'success');
            
            delete persistentJiraCounts[id];
            savePersistentCountsToStorage();
            
            loadEngagements(currentPage, currentFilters);
        } else {
            showAlert(result.error || 'Failed to close engagement', 'danger');
        }
    } catch (error) {
        console.error('Failed to close engagement:', error);
    }
}

function openChangelogsModal() {
    if (!currentEngagementId) {
        showAlert('No engagement selected', 'danger');
        return;
    }
    
    document.getElementById('changelogText').value = '';
    document.getElementById('extractedJiras').value = '';
    document.getElementById('jiraCount').textContent = 'Count: 0';
    document.getElementById('addTestsBtn').disabled = true;
    document.getElementById('creationSummary').style.display = 'none';
    
    showModal('changelogsModal');
}

async function fetchJiraIds() {
    const changelogText = document.getElementById('changelogText').value.trim();
    
    if (!changelogText) {
        showAlert('Please enter changelog text first', 'warning');
        return;
    }
    
    try {
        const response = await apiCall('/api/parse-jira', {
            method: 'POST',
            body: JSON.stringify({ text: changelogText })
        });
        
        if (response.success) {
            const jiraIds = response.jira_ids;
            const count = response.count;
            
            document.getElementById('extractedJiras').value = jiraIds.join(', ');
            document.getElementById('jiraCount').textContent = `Count: ${count}`;
            document.getElementById('addTestsBtn').disabled = count === 0;
            
            if (count > 0) {
                showAlert(`Found ${count} unique JIRA ID(s)`, 'success');
            } else {
                showAlert('No JIRA IDs found in the text', 'info');
            }
        } else {
            showAlert(response.error || 'Failed to parse JIRA IDs', 'danger');
        }
    } catch (error) {
        console.error('Failed to fetch JIRA IDs:', error);
    }
}

async function createJiraTests() {
    const extractedJiras = document.getElementById('extractedJiras').value.trim();
    
    if (!extractedJiras) {
        showAlert('No JIRA IDs to process', 'warning');
        return;
    }
    
    if (!currentEngagementId) {
        showAlert('No engagement selected', 'danger');
        return;
    }
    
    const jiraIds = extractedJiras.split(',').map(id => id.trim()).filter(id => id);
    
    try {
        const response = await apiCall('/api/create-tests', {
            method: 'POST',
            body: JSON.stringify({
                engagement_id: currentEngagementId,
                jira_ids: jiraIds
            })
        });
        
        if (response.success) {
            const summary = response.summary;
            const details = response.details;
            
            document.getElementById('createdCount').textContent = summary.created;
            document.getElementById('skippedCount').textContent = summary.skipped;
            document.getElementById('errorCount').textContent = summary.errors;
            
            let detailsHtml = '';
            
            if (details.created_tests.length > 0) {
                detailsHtml += '<div><strong>Created Tests:</strong><ul>';
                details.created_tests.forEach(test => {
                    detailsHtml += `<li>${test.jira_id} (ID: ${test.test_id})</li>`;
                });
                detailsHtml += '</ul></div>';
            }
            
            if (details.skipped_tests.length > 0) {
                detailsHtml += '<div><strong>Skipped (Already Exist):</strong><ul>';
                details.skipped_tests.forEach(jiraId => {
                    detailsHtml += `<li>${jiraId}</li>`;
                });
                detailsHtml += '</ul></div>';
            }
            
            if (details.errors.length > 0) {
                detailsHtml += '<div><strong>Errors:</strong><ul>';
                details.errors.forEach(error => {
                    detailsHtml += `<li>${error}</li>`;
                });
                detailsHtml += '</ul></div>';
            }
            
            document.getElementById('detailsList').innerHTML = detailsHtml;
            document.getElementById('creationSummary').style.display = 'block';
            
            showAlert(`Test creation completed: ${summary.created} created, ${summary.skipped} skipped, ${summary.errors} errors`, 'success');
            
        } else {
            showAlert(response.error || 'Failed to create tests', 'danger');
        }
    } catch (error) {
        console.error('Failed to create JIRA tests:', error);
    }
}

document.getElementById('engagementForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const tagsValue = document.getElementById('tags').value;
    const tags = tagsValue ? tagsValue.split(',').map(tag => tag.trim()).filter(tag => tag) : [];
    
    const formData = {
        tags: tags,
        name: document.getElementById('name').value,
        status: document.getElementById('status').value,
        target_start: document.getElementById('targetStart').value,
        target_end: document.getElementById('targetEnd').value,
        lead: parseInt(document.getElementById('lead').value) || null,
        product: parseInt(document.getElementById('product').value),
        reason: document.getElementById('createdBy').value || ''
    };
    
    const id = document.getElementById('engagementId').value;
    if (id) {
        formData.version = document.getElementById('version').value;
        formData.description = document.getElementById('description').value;
        formData.build_id = document.getElementById('buildId').value;
        formData.commit_hash = document.getElementById('commitHash').value;
    }
    
    try {
        if (id) {
            const result = await apiCall(`/api/engagements/${id}`, {
                method: 'PUT',
                body: JSON.stringify(formData)
            });
            if (result.success) {
                showAlert('Engagement updated successfully!', 'success');
            } else {
                showAlert(result.error || 'Failed to update engagement', 'danger');
                return;
            }
        } else {
            const result = await apiCall('/api/engagements', {
                method: 'POST',
                body: JSON.stringify(formData)
            });
            if (result.success) {
                showAlert('Engagement created successfully!', 'success');
            } else {
                showAlert(result.error || 'Failed to create engagement', 'danger');
                return;
            }
        }
        
        hideModal('engagementModal');
        loadEngagements(currentPage, currentFilters);
        
    } catch (error) {
        console.error('Failed to save engagement:', error);
    }
});

document.getElementById('nameFilter').addEventListener('input', debounce(function() {
    if (this.value.length >= 3 || this.value.length === 0) {
        applyFilters();
    }
}, 500));

document.addEventListener('DOMContentLoaded', function() {
    const hadCachedData = loadPersistentCountsFromStorage();
    if (hadCachedData) {
        console.log('Browser restart persistent cache loaded successfully');
    }
    
    loadFilterOptions().then(() => {
        loadEngagements();
        
        setTimeout(() => {
            updateFetchTestsButton();
        }, 500);
    });
    
    if (hadCachedData) {
        showAlert('✅ JIRA counts restored from browser cache (survives restarts)', 'success');
    }
});
</script>
{% endblock %}'''

templates['engagements.html'] = engagements_template

print("Created Engagements template for v8")