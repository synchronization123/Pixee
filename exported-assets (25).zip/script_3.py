# Create updated Review template with new filtering logic
review_template = '''{% extends "base.html" %}

{% block title %}Review - DefectDojo Clone{% endblock %}

{% block content %}
<div class="page-header">
    <h1 class="page-title">📋 IR Review Workflow</h1>
    
    <div class="status-counts" id="reviewStatusCounts">
        <div class="status-count">Pending Review: <span id="pendingReviewCount">0</span></div>
        <div class="status-count">On Hold: <span id="onHoldReviewCount">0</span></div>
    </div>
    
    <div class="btn-group">
        <button type="button" class="btn btn-secondary" onclick="refreshReviews()">
            🔄 Refresh
        </button>
    </div>
</div>

<div id="alert-container"></div>

<div class="filters">
    <div class="filter-grid-wide">
        <div class="form-group">
            <label class="form-label">Filter by Tag</label>
            <select class="form-control" id="tagFilter" onchange="loadReviewEngagements()">
                <option value="" selected>All Tags</option>
                <option value="pci">PCI</option>
                <option value="mcr">MCR</option>
                <option value="patch">Patch</option>
                <option value="vapt">VAPT</option>
            </select>
        </div>
        <div class="form-group">
            <button type="button" class="btn btn-secondary" onclick="resetTagFilter()">
                🔄 Reset Filter
            </button>
        </div>
    </div>
</div>

<div id="noReviewMessage" class="card" style="display: none;">
    <div class="card-body text-center" style="padding: 60px;">
        <h3 style="color: #666; margin-bottom: 20px;">📋 No Engagements Awaiting Review</h3>
        <p style="color: #888; font-size: 16px;">
            Engagements appear here when:<br>
            • IR field has been entered<br>
            • Lead Review Status is "Not Started" or "On Hold"
        </p>
    </div>
</div>

<div id="reviewContainer">
</div>
{% endblock %}

{% block extra_js %}
<script>
let reviewEngagements = [];
let currentTagFilter = '';

async function loadReviewEngagements() {
    try {
        currentTagFilter = document.getElementById('tagFilter').value;
        
        const params = new URLSearchParams();
        if (currentTagFilter) {
            params.append('tag', currentTagFilter);
        }
        
        const response = await apiCall(`/api/review-engagements?${params}`);
        
        if (response.success) {
            reviewEngagements = response.engagements;
            displayReviewEngagements();
            updateReviewCounts();
        } else {
            showAlert(response.error || 'Failed to load review engagements', 'danger');
            reviewEngagements = [];
            displayReviewEngagements();
        }
        
    } catch (error) {
        console.error('Failed to load review engagements:', error);
        reviewEngagements = [];
        displayReviewEngagements();
    }
}

function displayReviewEngagements() {
    const container = document.getElementById('reviewContainer');
    const noReviewMessage = document.getElementById('noReviewMessage');
    
    if (reviewEngagements.length === 0) {
        container.innerHTML = '';
        noReviewMessage.style.display = 'block';
        return;
    }
    
    noReviewMessage.style.display = 'none';
    
    let html = '';
    
    reviewEngagements.forEach((engagement, index) => {
        const ir = engagement.version || '';
        const engagementName = engagement.name || `Engagement ${engagement.id}`;
        const assignedTo = engagement.lead_name || 'Unassigned';
        const currentStatus = engagement.commit_hash || 'Not Started';
        const currentComment = engagement.branch_tag || '';
        const mentorReviewStatus = engagement.build_id || 'Not Started';
        
        html += `
            <div class="review-item" id="reviewItem_${engagement.id}">
                <div class="review-header">
                    For <strong>${engagementName}</strong>: 
                    Submitted by <strong>${assignedTo}</strong>
                    <br>
                    <!-- ENHANCED v8: IR Display in bold near Lead Review Status -->
                    <div style="margin: 10px 0; padding: 8px 12px; background: #f8f9fa; border-left: 4px solid #3498db; border-radius: 4px;">
                        <strong style="color: #2c3e50;">IR: ${ir}</strong> | Lead Review Status
                    </div>
                    <div style="margin-top: 8px; font-size: 14px; color: #666;">
                        Mentor Review Status: <strong style="color: #27ae60;">${mentorReviewStatus}</strong>
                    </div>
                </div>
                
                <div class="review-controls">
                    <div class="review-comment">
                        <label class="form-label">Lead Review Status</label>
                        <select class="form-control" id="status_${engagement.id}">
                            <option value="Not Started" ${currentStatus === 'Not Started' ? 'selected' : ''}>Not Started</option>
                            <option value="Approved" ${currentStatus === 'Approved' ? 'selected' : ''}>Approved</option>
                            <option value="Approved with Exception" ${currentStatus === 'Approved with Exception' ? 'selected' : ''}>Approved with Exception</option>
                            <option value="Rejected" ${currentStatus === 'Rejected' ? 'selected' : ''}>Rejected</option>
                            <option value="Repatched" ${currentStatus === 'Repatched' ? 'selected' : ''}>Repatched</option>
                            <option value="On Hold" ${currentStatus === 'On Hold' ? 'selected' : ''}>On Hold</option>
                        </select>
                        
                        <label class="form-label" style="margin-top: 10px;">Review Comment (150 characters max)</label>
                        <textarea 
                            class="form-control" 
                            id="comment_${engagement.id}" 
                            maxlength="150" 
                            placeholder="Enter review comment..."
                            oninput="updateCharCounter('comment_${engagement.id}', 'counter_${engagement.id}', 150)"
                        >${currentComment}</textarea>
                        <div class="char-counter" id="counter_${engagement.id}">150/150</div>
                    </div>
                    
                    <div style="display: flex; flex-direction: column; gap: 15px;">
                        <button type="button" class="btn btn-success" onclick="saveReview(${engagement.id})" title="Save Review">
                            💾 Save Review
                        </button>
                    </div>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
    
    // Initialize character counters
    reviewEngagements.forEach(engagement => {
        updateCharCounter(`comment_${engagement.id}`, `counter_${engagement.id}`, 150);
    });
}

async function saveReview(engagementId) {
    try {
        const statusElement = document.getElementById(`status_${engagementId}`);
        const commentElement = document.getElementById(`comment_${engagementId}`);
        
        if (!statusElement || !commentElement) {
            showAlert('Could not find review fields', 'danger');
            return;
        }
        
        const status = statusElement.value;
        const comment = commentElement.value.trim();
        
        if (!status) {
            showAlert('Please select a review status', 'warning');
            return;
        }
        
        // Find engagement for data
        const engagement = reviewEngagements.find(e => e.id === engagementId);
        if (!engagement) {
            showAlert('Could not find engagement details', 'danger');
            return;
        }
        
        const engagementName = engagement.name || `Engagement ${engagementId}`;
        const ir = engagement.version || '';
        const confirmMessage = `Save review for "${engagementName}" with IR "${ir}" and status "${status}"?`;
        
        if (!confirm(confirmMessage)) {
            return;
        }
        
        // Use engagement API with mandatory parameters: id, name, target_start, target_end, lead, product
        const updateData = {
            id: engagementId,
            name: engagement.name || '',
            target_start: engagement.target_start || '',
            target_end: engagement.target_end || '',
            lead: engagement.lead,
            product: engagement.product,
            commit_hash: status,      // Lead Review Status
            branch_tag: comment       // Comment (150 chars)
        };
        
        const response = await apiCall(`/api/engagements/${engagementId}`, {
            method: 'PUT',
            body: JSON.stringify(updateData)
        });
        
        if (response.success) {
            showAlert(`✅ Review saved successfully for ${engagementName} with IR ${ir} using mandatory parameters!`, 'success');
            
            // v8 UPDATE: Remove from current list if status is no longer 'Not Started' or 'On Hold'
            if (status !== 'Not Started' && status !== 'On Hold') {
                reviewEngagements = reviewEngagements.filter(e => e.id !== engagementId);
                
                // Remove from DOM with animation
                const reviewItem = document.getElementById(`reviewItem_${engagementId}`);
                if (reviewItem) {
                    reviewItem.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
                    reviewItem.style.opacity = '0';
                    reviewItem.style.transform = 'translateX(-100%)';
                    
                    setTimeout(() => {
                        displayReviewEngagements();
                        updateReviewCounts();
                    }, 300);
                } else {
                    displayReviewEngagements();
                    updateReviewCounts();
                }
            } else {
                // Update the engagement in the list
                const engagementIndex = reviewEngagements.findIndex(e => e.id === engagementId);
                if (engagementIndex !== -1) {
                    reviewEngagements[engagementIndex].commit_hash = status;
                    reviewEngagements[engagementIndex].branch_tag = comment;
                }
                updateReviewCounts();
            }
            
        } else {
            showAlert(response.error || 'Failed to save review', 'danger');
        }
        
    } catch (error) {
        console.error('Failed to save review:', error);
        showAlert('Failed to save review', 'danger');
    }
}

function updateReviewCounts() {
    let pendingCount = 0;
    let onHoldCount = 0;
    
    reviewEngagements.forEach(engagement => {
        const status = engagement.commit_hash || 'Not Started';
        if (status === 'Not Started') {
            pendingCount++;
        } else if (status === 'On Hold') {
            onHoldCount++;
        }
    });
    
    document.getElementById('pendingReviewCount').textContent = pendingCount;
    document.getElementById('onHoldReviewCount').textContent = onHoldCount;
}

function resetTagFilter() {
    document.getElementById('tagFilter').value = '';
    currentTagFilter = '';
    loadReviewEngagements();
    showAlert('Filter reset successfully!', 'success');
}

function refreshReviews() {
    loadReviewEngagements();
    showAlert('Reviews refreshed successfully!', 'success');
}

// Auto-refresh every 5 minutes
setInterval(() => {
    console.log('Auto-refreshing review data...');
    loadReviewEngagements();
}, 300000);

// Load review engagements on page load
document.addEventListener('DOMContentLoaded', function() {
    loadReviewEngagements();
});

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.key === 'r') {
        e.preventDefault();
        refreshReviews();
    }
    
    if (e.ctrlKey && e.key === 's' && reviewEngagements.length > 0) {
        e.preventDefault();
        saveReview(reviewEngagements[0].id);
    }
});
</script>
{% endblock %}'''

templates['review.html'] = review_template

print("Created updated Review template with new v8 filtering logic")