# Create remaining templates (same as previous versions)

# Base template - same as before but with v8 branding
base_template = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}DefectDojo Clone v8{% endblock %}</title>
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            color: #333;
            line-height: 1.6;
        }
        
        .container {
            width: 100%;
            max-width: 100%;
            margin: 0;
            padding: 0 20px;
        }
        
        .navbar {
            background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
            padding: 15px 0;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            width: 100%;
        }
        
        .navbar .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }
        
        .navbar-brand {
            color: white;
            text-decoration: none;
            font-size: 24px;
            font-weight: bold;
        }
        
        .nav-menu {
            display: flex;
            list-style: none;
            gap: 30px;
        }
        
        .nav-link {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 5px;
            transition: background-color 0.2s ease;
        }
        
        .nav-link:hover,
        .nav-link.active {
            background-color: rgba(255,255,255,0.2);
        }
        
        .main-content {
            margin-top: 30px;
            width: 100%;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 2px solid #3498db;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .page-title {
            font-size: 28px;
            color: #2c3e50;
        }
        
        .status-counts {
            display: flex;
            gap: 20px;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .status-count {
            background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);
            color: white;
            padding: 10px 15px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: bold;
            box-shadow: 0 2px 5px rgba(52, 152, 219, 0.3);
        }
        
        .btn-group {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .btn {
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: transform 0.15s ease, box-shadow 0.15s ease;
            white-space: nowrap;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 2px 8px rgba(52, 152, 219, 0.3);
        }
        
        .btn-secondary {
            background: #95a5a6;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #7f8c8d;
        }
        
        .btn-success {
            background: #27ae60;
            color: white;
        }
        
        .btn-success:hover {
            background: #229954;
        }
        
        .btn-warning {
            background: #f39c12;
            color: white;
        }
        
        .btn-warning:hover {
            background: #e67e22;
        }
        
        .btn-danger {
            background: #e74c3c;
            color: white;
        }
        
        .btn-danger:hover {
            background: #c0392b;
        }
        
        .btn-info {
            background: #17a2b8;
            color: white;
        }
        
        .btn-info:hover {
            background: #138496;
        }
        
        .btn-small {
            padding: 6px 12px;
            font-size: 12px;
        }
        
        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            width: 100%;
        }
        
        .card-header {
            background: linear-gradient(135deg, #34495e 0%, #2c3e50 100%);
            color: white;
            padding: 15px 20px;
            border-radius: 8px 8px 0 0;
            font-weight: bold;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .dashboard-controls {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
        }
        
        .dashboard-controls label {
            font-weight: bold;
            color: #2c3e50;
            font-size: 16px;
        }
        
        .dashboard-controls select {
            padding: 10px 15px;
            border: 2px solid #bdc3c7;
            border-radius: 5px;
            font-size: 14px;
            background: white;
            cursor: pointer;
            min-width: 150px;
        }
        
        .dashboard-controls select:focus {
            outline: none;
            border-color: #3498db;
        }
        
        .radio-group {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        
        .radio-group label {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            font-size: 14px;
        }
        
        .radio-group input[type="radio"] {
            margin: 0;
        }
        
        .filters {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            width: 100%;
        }
        
        .filter-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            align-items: end;
            width: 100%;
        }
        
        .filter-grid-wide {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            align-items: end;
            width: 100%;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
            min-width: 0;
        }
        
        .form-label {
            margin-bottom: 5px;
            font-weight: bold;
            color: #2c3e50;
            font-size: 14px;
        }
        
        .form-control {
            padding: 10px;
            border: 2px solid #bdc3c7;
            border-radius: 5px;
            font-size: 14px;
            transition: border-color 0.2s ease;
            width: 100%;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #3498db;
        }
        
        .checkbox-cell {
            text-align: center;
            width: 50px;
        }
        
        .checkbox-cell input[type="checkbox"] {
            transform: scale(1.2);
            cursor: pointer;
        }
        
        .select-all-checkbox {
            margin-right: 8px;
            transform: scale(1.2);
        }
        
        .review-item {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            margin-bottom: 15px;
            padding: 20px;
        }
        
        .review-header {
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 15px;
            font-size: 16px;
        }
        
        .review-controls {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 15px;
            align-items: end;
        }
        
        .review-comment {
            position: relative;
        }
        
        .char-counter {
            position: absolute;
            bottom: -20px;
            right: 10px;
            font-size: 12px;
            color: #666;
        }
        
        .char-counter.warning {
            color: #f39c12;
        }
        
        .char-counter.danger {
            color: #e74c3c;
        }
        
        .ir-display {
            background: #f8f9fa;
            padding: 8px 12px;
            border-radius: 4px;
            border-left: 4px solid #3498db;
            margin: 10px 0;
            font-weight: bold;
            color: #2c3e50;
        }
        
        .pagination-info {
            background: white;
            padding: 15px 20px;
            margin-bottom: 10px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .total-records {
            font-size: 16px;
            font-weight: bold;
            color: #2c3e50;
        }
        
        .pagination-controls {
            display: flex;
            gap: 5px;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .table-container {
            overflow-x: auto;
            width: 100%;
            max-width: 100%;
        }
        
        .table {
            width: 100%;
            min-width: 1400px;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .table thead th {
            background: linear-gradient(135deg, #34495e 0%, #2c3e50 100%);
            color: white;
            padding: 15px 8px;
            text-align: left;
            font-weight: bold;
            font-size: 13px;
            position: sticky;
            top: 0;
            z-index: 10;
        }
        
        .jira-header {
            background: linear-gradient(135deg, #8e44ad 0%, #9b59b6 100%);
            color: white;
            text-align: center;
            font-size: 12px;
            font-weight: bold;
            border-left: 2px solid white;
        }
        
        .jira-subheader {
            background: linear-gradient(135deg, #9b59b6 0%, #8e44ad 100%);
            color: white;
            text-align: center;
            font-size: 11px;
            padding: 10px 4px;
            min-width: 30px;
            border-right: 1px solid rgba(255,255,255,0.3);
            cursor: help;
        }
        
        .jira-count {
            background: #f8f9fa;
            text-align: center;
            font-size: 12px;
            font-weight: bold;
            color: #2c3e50;
            padding: 8px 4px;
            border-right: 1px solid #ecf0f1;
            min-width: 30px;
        }
        
        .jira-count.loading {
            color: #95a5a6;
            font-style: italic;
        }
        
        .jira-count.fetched {
            background: #d5f4e6 !important;
            color: #27ae60 !important;
            border: 1px solid #27ae60 !important;
            font-weight: bold !important;
        }
        
        .rm-eta-today {
            color: #e74c3c !important;
            background: #ffeaea !important;
            font-weight: bold !important;
            padding: 4px 8px !important;
            border-radius: 4px !important;
            border: 1px solid #e74c3c !important;
        }
        
        .table tbody td {
            padding: 12px 8px;
            border-bottom: 1px solid #ecf0f1;
            font-size: 13px;
            word-wrap: break-word;
            max-width: 150px;
        }
        
        .table tbody tr:hover {
            background-color: #f8f9fa;
        }
        
        .table tbody tr:nth-child(even) {
            background-color: #fcfcfc;
        }
        
        .table tbody tr:nth-child(even):hover {
            background-color: #f0f0f0;
        }
        
        .dashboard-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .dashboard-table thead th {
            background: linear-gradient(135deg, #34495e 0%, #2c3e50 100%);
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: bold;
            font-size: 14px;
        }
        
        .dashboard-table tbody td {
            padding: 12px;
            border-bottom: 1px solid #ecf0f1;
            font-size: 13px;
        }
        
        .dashboard-table tbody tr:hover {
            background-color: #f8f9fa;
        }
        
        .env-subheader {
            background: linear-gradient(135deg, #16a085 0%, #1abc9c 100%);
            color: white;
            text-align: center;
            font-size: 11px;
            padding: 8px 4px;
            min-width: 50px;
            border-right: 1px solid rgba(255,255,255,0.3);
        }
        
        .env-count {
            background: #f8f9fa;
            text-align: center;
            font-size: 12px;
            font-weight: bold;
            color: #2c3e50;
            padding: 8px 4px;
            border-right: 1px solid #ecf0f1;
            min-width: 50px;
        }
        
        .task-type {
            display: inline-block;
            background: #3498db;
            color: white;
            padding: 2px 6px;
            border-radius: 10px;
            font-size: 10px;
            margin: 1px;
            font-weight: bold;
        }
        
        .task-type.pci { background: #e74c3c; }
        .task-type.patch { background: #f39c12; }
        .task-type.vapt { background: #9b59b6; }
        .task-type.mcr { background: #27ae60; }
        .task-type.contrast { background: #9b59b6; }
        .task-type.sonar { background: #34495e; }
        
        .badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: bold;
            color: white;
            display: inline-block;
            text-align: center;
        }
        
        .badge-success { background: #27ae60; }
        .badge-danger { background: #e74c3c; }
        .badge-warning { background: #f39c12; color: #333; }
        .badge-info { background: #3498db; }
        .badge-secondary { background: #95a5a6; }
        .badge-primary { background: #3498db; }
        
        .severity-Critical { background: #e74c3c; }
        .severity-High { background: #e67e22; }
        .severity-Medium { background: #f39c12; color: #333; }
        .severity-Low { background: #27ae60; }
        .severity-Info { background: #3498db; }
        
        .pagination {
            display: flex;
            justify-content: center;
            gap: 5px;
            margin-top: 20px;
            flex-wrap: wrap;
        }
        
        .pagination a,
        .pagination span {
            padding: 10px 15px;
            border: 1px solid #bdc3c7;
            text-decoration: none;
            color: #2c3e50;
            border-radius: 5px;
            transition: all 0.2s ease;
            font-size: 14px;
            font-weight: 500;
        }
        
        .pagination a:hover {
            background: #3498db;
            color: white;
            border-color: #3498db;
        }
        
        .pagination .current {
            background: #3498db;
            color: white;
            border-color: #3498db;
        }
        
        .pagination-controls a,
        .pagination-controls span {
            padding: 10px 15px;
            border: 1px solid #bdc3c7;
            text-decoration: none;
            color: #2c3e50;
            border-radius: 5px;
            transition: all 0.2s ease;
            font-size: 14px;
            font-weight: 500;
        }
        
        .pagination-controls a:hover {
            background: #3498db;
            color: white;
            border-color: #3498db;
        }
        
        .pagination-controls .current {
            background: #3498db;
            color: white;
            border-color: #3498db;
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            animation: fadeIn 0.2s ease;
        }
        
        .modal.show {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .modal-content {
            background: white;
            border-radius: 8px;
            width: 90%;
            max-width: 900px;
            max-height: 90vh;
            overflow-y: auto;
            animation: slideIn 0.2s ease;
        }
        
        .modal-header {
            background: linear-gradient(135deg, #34495e 0%, #2c3e50 100%);
            color: white;
            padding: 20px;
            border-radius: 8px 8px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-title {
            font-size: 20px;
            font-weight: bold;
        }
        
        .modal-close {
            background: none;
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
            padding: 5px;
            border-radius: 3px;
            transition: background-color 0.2s ease;
        }
        
        .modal-close:hover {
            background-color: rgba(255,255,255,0.2);
        }
        
        .modal-body {
            padding: 20px;
        }
        
        .modal-footer {
            padding: 15px 20px;
            border-top: 1px solid #ecf0f1;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        
        .form-grid-full {
            grid-column: 1 / -1;
        }
        
        .loading {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 9999;
            align-items: center;
            justify-content: center;
        }
        
        .loading.show {
            display: flex;
        }
        
        .spinner {
            width: 50px;
            height: 50px;
            border: 4px solid #f3f3f3;
            border-top: 4px solid #3498db;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            position: relative;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .alert-warning {
            background-color: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }
        
        .alert-info {
            background-color: #cce7ff;
            color: #004085;
            border: 1px solid #a6d4ff;
        }
        
        .alert-close {
            position: absolute;
            top: 15px;
            right: 20px;
            background: none;
            border: none;
            font-size: 18px;
            cursor: pointer;
            color: inherit;
        }
        
        .progress {
            background: #ecf0f1;
            border-radius: 10px;
            overflow: hidden;
            height: 20px;
        }
        
        .progress-bar {
            height: 100%;
            background: linear-gradient(90deg, #27ae60 0%, #2ecc71 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 12px;
            font-weight: bold;
            transition: width 0.3s ease;
        }
        
        input[type="date"] {
            padding: 10px;
            border: 2px solid #bdc3c7;
            border-radius: 5px;
            font-size: 14px;
            width: 100%;
        }
        
        input[type="date"]:focus {
            outline: none;
            border-color: #3498db;
        }
        
        select.form-control {
            padding: 10px;
            border: 2px solid #bdc3c7;
            border-radius: 5px;
            font-size: 14px;
            background: white;
            cursor: pointer;
        }
        
        select.form-control:focus {
            outline: none;
            border-color: #3498db;
        }
        
        textarea.form-control {
            padding: 10px;
            border: 2px solid #bdc3c7;
            border-radius: 5px;
            font-size: 14px;
            resize: vertical;
            min-height: 80px;
            font-family: Arial, sans-serif;
        }
        
        textarea.form-control:focus {
            outline: none;
            border-color: #3498db;
        }
        
        textarea.form-control[readonly] {
            background-color: #f8f9fa;
            color: #6c757d;
            cursor: not-allowed;
        }
        
        .summary-section {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-top: 15px;
            border-left: 4px solid #3498db;
        }
        
        .summary-title {
            font-weight: bold;
            margin-bottom: 10px;
            color: #2c3e50;
        }
        
        .summary-stats {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }
        
        .summary-stat {
            background: white;
            padding: 10px 15px;
            border-radius: 5px;
            border: 1px solid #dee2e6;
        }
        
        .summary-stat .number {
            font-size: 20px;
            font-weight: bold;
            color: #3498db;
        }
        
        .summary-stat .label {
            font-size: 12px;
            color: #666;
        }
        
        [title] {
            cursor: help;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes slideIn {
            from { transform: translateY(-30px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        @media (max-width: 768px) {
            .navbar .container {
                flex-direction: column;
                gap: 15px;
            }
            
            .nav-menu {
                flex-wrap: wrap;
                justify-content: center;
                gap: 15px;
            }
            
            .page-header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            .status-counts {
                justify-content: center;
            }
            
            .pagination-info {
                flex-direction: column;
                text-align: center;
            }
            
            .filter-grid,
            .filter-grid-wide {
                grid-template-columns: 1fr;
            }
            
            .modal-content {
                width: 95%;
                margin: 10px;
            }
            
            .table {
                min-width: 1200px;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .summary-stats {
                justify-content: center;
            }
            
            .dashboard-controls {
                flex-direction: column;
                text-align: center;
                gap: 15px;
            }
            
            .radio-group {
                flex-direction: column;
                gap: 10px;
            }
            
            .review-controls {
                grid-template-columns: 1fr;
            }
        }
        
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .mt-20 { margin-top: 20px; }
        .mb-20 { margin-bottom: 20px; }
        .hidden { display: none; }
        .flex { display: flex; }
        .justify-center { justify-content: center; }
        .align-center { align-items: center; }
        .gap-10 { gap: 10px; }
        .w-full { width: 100%; }
        
        * {
            will-change: auto;
        }
        
        .table tbody tr {
            contain: layout;
        }
        
        .card {
            contain: layout style;
        }
    </style>
    
    {% block extra_css %}{% endblock %}
</head>
<body>
    <div class="loading" id="loadingOverlay">
        <div class="spinner"></div>
    </div>

    <nav class="navbar">
        <div class="container">
            <a href="/" class="navbar-brand">🛡️ DefectDojo Clone v8</a>
            <ul class="nav-menu">
                <li><a href="/" class="nav-link" id="dashboard-link">Dashboard</a></li>
                <li><a href="/engagements" class="nav-link" id="engagements-link">Engagements</a></li>
                <li><a href="/tests" class="nav-link" id="tests-link">Tests</a></li>
                <li><a href="/reassign" class="nav-link" id="reassign-link">Reassign</a></li>
                <li><a href="/review" class="nav-link" id="review-link">Review</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <main class="main-content">
            {% block content %}{% endblock %}
        </main>
    </div>

    <script>
        let loadingTimeoutId = null;
        
        function showLoading() {
            clearTimeout(loadingTimeoutId);
            document.getElementById('loadingOverlay').classList.add('show');
        }
        
        function hideLoading() {
            loadingTimeoutId = setTimeout(() => {
                document.getElementById('loadingOverlay').classList.remove('show');
            }, 100);
        }
        
        function showAlert(message, type = 'info') {
            const alertHtml = `
                <div class="alert alert-${type}">
                    ${message}
                    <button type="button" class="alert-close" onclick="this.parentElement.remove()">×</button>
                </div>
            `;
            
            const container = document.querySelector('.main-content');
            container.insertAdjacentHTML('afterbegin', alertHtml);
            
            setTimeout(() => {
                const alert = document.querySelector('.alert');
                if (alert && alert.parentElement) {
                    alert.remove();
                }
            }, 5000);
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            const currentPath = window.location.pathname;
            const navLinks = document.querySelectorAll('.nav-link');
            
            navLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === currentPath) {
                    link.classList.add('active');
                }
            });
            
            if (currentPath === '/') {
                document.getElementById('dashboard-link').classList.add('active');
            }
        });
        
        async function apiCall(url, options = {}) {
            showLoading();
            try {
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 30000);
                
                const response = await fetch(url, {
                    headers: {
                        'Content-Type': 'application/json',
                        ...options.headers
                    },
                    signal: controller.signal,
                    ...options
                });
                
                clearTimeout(timeoutId);
                
                const data = await response.json();
                
                if (data.error) {
                    throw new Error(data.error);
                }
                
                return data;
            } catch (error) {
                if (error.name === 'AbortError') {
                    showAlert('Request timeout - please try again', 'warning');
                } else {
                    showAlert(error.message, 'danger');
                }
                throw error;
            } finally {
                hideLoading();
            }
        }
        
        function formatSeverityBadge(severity) {
            return `<span class="badge severity-${severity}">${severity}</span>`;
        }
        
        function formatStatusBadge(status, type = 'primary') {
            return `<span class="badge badge-${type}">${status}</span>`;
        }
        
        function formatDate(dateString) {
            if (!dateString) return 'N/A';
            try {
                return new Date(dateString).toISOString().split('T')[0];
            } catch {
                return 'N/A';
            }
        }
        
        function formatAging(days) {
            if (days === 0 || days === null || days === undefined) return '0 days';
            return `${days} day${days !== 1 ? 's' : ''}`;
        }
        
        function isDateToday(dateString) {
            if (!dateString) return false;
            try {
                const date = new Date(dateString + 'T00:00:00');
                const today = new Date();
                return date.getDate() === today.getDate() && 
                       date.getMonth() === today.getMonth() && 
                       date.getFullYear() === today.getFullYear();
            } catch {
                return false;
            }
        }
        
        function showModal(modalId) {
            document.getElementById(modalId).classList.add('show');
        }
        
        function hideModal(modalId) {
            document.getElementById(modalId).classList.remove('show');
        }
        
        function createEnhancedPagination(currentPage, totalPages, onPageClick) {
            if (totalPages <= 1) return '';
            
            let html = '';
            
            if (currentPage > 1) {
                html += `<a href="#" onclick="${onPageClick}(1); return false;" title="First page">First</a>`;
            }
            
            if (currentPage > 1) {
                html += `<a href="#" onclick="${onPageClick}(${currentPage - 1}); return false;" title="Previous page">Prev</a>`;
            }
            
            let startPage = Math.max(1, currentPage - 2);
            let endPage = Math.min(totalPages, currentPage + 2);
            
            if (endPage - startPage < 4) {
                if (startPage === 1) {
                    endPage = Math.min(totalPages, startPage + 4);
                } else if (endPage === totalPages) {
                    startPage = Math.max(1, endPage - 4);
                }
            }
            
            if (startPage > 1) {
                if (startPage > 2) {
                    html += `<span>...</span>`;
                }
            }
            
            for (let i = startPage; i <= endPage; i++) {
                if (i === currentPage) {
                    html += `<span class="current">${i}</span>`;
                } else {
                    html += `<a href="#" onclick="${onPageClick}(${i}); return false;">${i}</a>`;
                }
            }
            
            if (endPage < totalPages) {
                if (endPage < totalPages - 1) {
                    html += `<span>...</span>`;
                }
            }
            
            if (currentPage < totalPages) {
                html += `<a href="#" onclick="${onPageClick}(${currentPage + 1}); return false;" title="Next page">Next</a>`;
            }
            
            if (currentPage < totalPages) {
                html += `<a href="#" onclick="${onPageClick}(${totalPages}); return false;" title="Last page">Last</a>`;
            }
            
            return html;
        }
        
        function updateCharCounter(textareaId, counterId, maxLength = 150) {
            const textarea = document.getElementById(textareaId);
            const counter = document.getElementById(counterId);
            
            if (textarea && counter) {
                const currentLength = textarea.value.length;
                const remaining = maxLength - currentLength;
                
                counter.textContent = `${remaining}/${maxLength}`;
                
                counter.classList.remove('warning', 'danger');
                if (remaining <= 10) {
                    counter.classList.add('danger');
                } else if (remaining <= 30) {
                    counter.classList.add('warning');
                }
            }
        }
        
        function getCurrentDate() {
            return new Date().toISOString().split('T')[0];
        }
        
        function debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }
    </script>
    
    {% block extra_js %}{% endblock %}
</body>
</html>'''

templates['base.html'] = base_template

# Dashboard template - same as before
dashboard_template = '''{% extends "base.html" %}

{% block title %}Dashboard - DefectDojo Clone v8{% endblock %}

{% block content %}
<div class="page-header">
    <h1 class="page-title">Analytics Dashboard</h1>
    <div class="btn-group">
        <button type="button" class="btn btn-primary" onclick="refreshDashboard()">
            🔄 Refresh
        </button>
    </div>
</div>

<div id="alert-container"></div>

<div class="dashboard-controls">
    <label for="assignedToSelector">Filter by Assigned To:</label>
    <select id="assignedToSelector" onchange="loadDashboardData()">
        <option value="" selected>All Users</option>
    </select>
    
    <div class="radio-group">
        <label>
            <input type="radio" name="viewType" value="tests_by_assigned" checked onchange="loadDashboardData()">
            Tests by Assigned To
        </label>
        <label>
            <input type="radio" name="viewType" value="tests_by_engagement" onchange="loadDashboardData()">
            Tests by Engagement
        </label>
    </div>
</div>

<div class="card">
    <div class="card-header" id="dashboardTableHeader">
        📊 Tests by Assigned To
    </div>
    <div class="card-body">
        <div class="table-container">
            <table class="dashboard-table" id="dashboardTable">
                <thead id="dashboardTableHead">
                </thead>
                <tbody id="dashboardTableBody">
                </tbody>
            </table>
        </div>
        
        <div id="noDataMessage" style="display: none; text-align: center; padding: 40px; color: #666;">
            <h3>📊 No Data Available</h3>
            <p>No JIRA tests found matching the current criteria.</p>
        </div>
    </div>
</div>
{% endblock %}

{% block extra_js %}
<script>
let currentViewType = 'tests_by_assigned';
let currentAssignedTo = '';
let availableEnvironments = new Set();

async function loadDashboardData() {
    try {
        currentAssignedTo = document.getElementById('assignedToSelector').value;
        currentViewType = document.querySelector('input[name="viewType"]:checked').value;
        
        document.getElementById('dashboardTableBody').innerHTML = '<tr><td colspan="10" style="text-align: center; padding: 40px;">Loading...</td></tr>';
        
        const params = new URLSearchParams({
            view_type: currentViewType,
            assigned_to: currentAssignedTo
        });
        
        const response = await apiCall(`/api/dashboard-data?${params}`);
        
        if (response.success) {
            displayDashboardData(response);
            updateAvailableUsers(response.available_users);
        } else {
            showAlert(response.error || 'Failed to load dashboard data', 'danger');
            showNoDataMessage();
        }
    } catch (error) {
        console.error('Failed to load dashboard data:', error);
        showAlert('Failed to load dashboard data', 'danger');
        showNoDataMessage();
    }
}

function displayDashboardData(response) {
    const data = response.data;
    const viewType = response.view_type;
    
    const header = document.getElementById('dashboardTableHeader');
    if (viewType === 'tests_by_assigned') {
        header.textContent = '📊 Tests by Assigned To';
    } else {
        header.textContent = '📊 Tests by Engagement';
    }
    
    availableEnvironments.clear();
    
    Object.values(data).forEach(item => {
        Object.keys(item.pending_by_env || {}).forEach(env => availableEnvironments.add(env));
        Object.keys(item.on_hold_by_env || {}).forEach(env => availableEnvironments.add(env));
    });
    
    const envList = Array.from(availableEnvironments).sort();
    
    generateTableHeaders(envList);
    generateTableBody(data, envList);
    
    if (Object.keys(data).length === 0) {
        showNoDataMessage();
    } else {
        hideNoDataMessage();
    }
}

function generateTableHeaders(environments) {
    const thead = document.getElementById('dashboardTableHead');
    
    let headerHtml = `
        <tr>
            <th rowspan="2" style="vertical-align: middle;">${currentViewType === 'tests_by_assigned' ? 'Assigned To' : 'Engagement'}</th>
            <th colspan="${Math.max(environments.length, 1)}" style="text-align: center; background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);">Pending Count</th>
            <th colspan="${Math.max(environments.length, 1)}" style="text-align: center; background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);">On Hold Count</th>
            <th rowspan="2" style="vertical-align: middle; text-align: center; background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);">Total</th>
        </tr>
        <tr>
    `;
    
    if (environments.length > 0) {
        environments.forEach(env => {
            headerHtml += `<th class="env-subheader">${env}</th>`;
        });
    } else {
        headerHtml += `<th class="env-subheader">No Env</th>`;
    }
    
    if (environments.length > 0) {
        environments.forEach(env => {
            headerHtml += `<th class="env-subheader">${env}</th>`;
        });
    } else {
        headerHtml += `<th class="env-subheader">No Env</th>`;
    }
    
    headerHtml += '</tr>';
    thead.innerHTML = headerHtml;
}

function generateTableBody(data, environments) {
    const tbody = document.getElementById('dashboardTableBody');
    let bodyHtml = '';
    
    let totalPendingByEnv = {};
    let totalOnHoldByEnv = {};
    let grandTotalPending = 0;
    let grandTotalOnHold = 0;
    
    environments.forEach(env => {
        totalPendingByEnv[env] = 0;
        totalOnHoldByEnv[env] = 0;
    });
    
    Object.keys(data).sort().forEach(entity => {
        const item = data[entity];
        bodyHtml += '<tr>';
        
        bodyHtml += `<td style="font-weight: bold;">${entity}</td>`;
        
        if (environments.length > 0) {
            environments.forEach(env => {
                const count = item.pending_by_env[env] || 0;
                bodyHtml += `<td class="env-count">${count}</td>`;
                totalPendingByEnv[env] += count;
            });
        } else {
            const count = item.total_pending || 0;
            bodyHtml += `<td class="env-count">${count}</td>`;
            grandTotalPending += count;
        }
        
        if (environments.length > 0) {
            environments.forEach(env => {
                const count = item.on_hold_by_env[env] || 0;
                bodyHtml += `<td class="env-count">${count}</td>`;
                totalOnHoldByEnv[env] += count;
            });
        } else {
            const count = item.total_on_hold || 0;
            bodyHtml += `<td class="env-count">${count}</td>`;
            grandTotalOnHold += count;
        }
        
        const rowTotal = item.total_pending + item.total_on_hold;
        bodyHtml += `<td style="font-weight: bold; text-align: center; background: #e8f4f8;">${rowTotal}</td>`;
        
        bodyHtml += '</tr>';
        
        if (environments.length > 0) {
            grandTotalPending += item.total_pending;
            grandTotalOnHold += item.total_on_hold;
        }
    });
    
    if (Object.keys(data).length > 0) {
        bodyHtml += '<tr style="background: #f8f9fa; border-top: 2px solid #3498db;">';
        bodyHtml += '<td style="font-weight: bold; font-size: 14px;">TOTAL</td>';
        
        if (environments.length > 0) {
            environments.forEach(env => {
                bodyHtml += `<td class="env-count" style="font-weight: bold; background: #fff3cd;">${totalPendingByEnv[env]}</td>`;
            });
        } else {
            bodyHtml += `<td class="env-count" style="font-weight: bold; background: #fff3cd;">${grandTotalPending}</td>`;
        }
        
        if (environments.length > 0) {
            environments.forEach(env => {
                bodyHtml += `<td class="env-count" style="font-weight: bold; background: #f8d7da;">${totalOnHoldByEnv[env]}</td>`;
            });
        } else {
            bodyHtml += `<td class="env-count" style="font-weight: bold; background: #f8d7da;">${grandTotalOnHold}</td>`;
        }
        
        const grandTotal = grandTotalPending + grandTotalOnHold;
        bodyHtml += `<td style="font-weight: bold; font-size: 16px; text-align: center; background: #cce7ff;">${grandTotal}</td>`;
        
        bodyHtml += '</tr>';
    }
    
    tbody.innerHTML = bodyHtml;
}

function updateAvailableUsers(users) {
    const selector = document.getElementById('assignedToSelector');
    const currentValue = selector.value;
    
    selector.innerHTML = '<option value="">All Users</option>';
    
    users.forEach(user => {
        const option = document.createElement('option');
        option.value = user.id;
        option.textContent = user.name;
        selector.appendChild(option);
    });
    
    const optionExists = Array.from(selector.options).some(option => option.value === currentValue);
    if (optionExists) {
        selector.value = currentValue;
    }
}

function showNoDataMessage() {
    document.getElementById('noDataMessage').style.display = 'block';
    document.querySelector('.table-container').style.display = 'none';
}

function hideNoDataMessage() {
    document.getElementById('noDataMessage').style.display = 'none';
    document.querySelector('.table-container').style.display = 'block';
}

async function refreshDashboard() {
    try {
        await apiCall('/api/refresh-dashboard');
        await loadDashboardData();
        showAlert('Dashboard refreshed successfully!', 'success');
    } catch (error) {
        console.error('Failed to refresh dashboard:', error);
        showAlert('Failed to refresh dashboard', 'danger');
    }
}

document.addEventListener('DOMContentLoaded', function() {
    loadDashboardData();
});

setInterval(() => {
    console.log('Auto-refreshing dashboard data...');
    loadDashboardData();
}, 300000);

document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.key === 'r') {
        e.preventDefault();
        refreshDashboard();
    }
});
</script>
{% endblock %}'''

templates['dashboard.html'] = dashboard_template

print("Created base and dashboard templates for v8")