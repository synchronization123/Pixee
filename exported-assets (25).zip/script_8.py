# Create enhanced batch and shell files for v8
batch_content = '''@echo off
echo ========================================================
echo DefectDojo Clone v8 - ULTIMATE ENHANCED GUI SYSTEM
echo ========================================================
echo.
echo 🎉 NEW v8 BREAKTHROUGH ENHANCEMENTS:
echo • ENHANCED GUI: Execute button + bigger interface (550x450)
echo • PROCESS MANAGEMENT: Prevents double execution + kills all on exit
echo • SYSTEM TRAY: Full integration with restore and exit options
echo • SMART UPDATES: New URL + file preservation + auto cleanup  
echo • REVIEW FILTER: Only commit_hash "Not Started"/"On Hold" shown
echo • VERSION FROM JSON: Dynamic version reading from version.json
echo.
echo 🚀 ENHANCED GUI LAUNCHER FEATURES:
echo • Double-click Dojo.pyw opens BIGGER professional interface
echo • Execute Portal button: Direct app.pyw launch (no version check)
echo • Launch Portal button: Auto-update with version checking
echo • Hide to Tray button: System tray integration with menu
echo • Process detection: Prevents double browser execution
echo • Exit functionality: Kills ALL app.pyw processes properly
echo.
echo 🛡️ REVIEW TAB CRITICAL UPDATE:
echo • NEW LOGIC: Only shows if commit_hash = "Not Started" or "On Hold"
echo • IR display: "IR:{value}" in bold near Lead Review Status
echo • Engagement PUT: Uses ALL 6 mandatory parameters
echo • Real-time removal: Engagements disappear when status changes
echo.
echo 🔧 ADVANCED SYSTEM FEATURES:
echo • New download URL: engagements/3/files/download/5/
echo • Smart file management: Preserves Dojo.pyw during updates
echo • Auto cleanup: Deletes zip files after extraction
echo • Process tracking: psutil integration for process management
echo • Enhanced error handling: Graceful recovery from all edge cases
echo.
echo 📋 TECHNICAL ARCHITECTURE ENHANCEMENTS:
echo • Bigger GUI window: 550x450 pixels for proper button layout
echo • Dual launch options: Execute (direct) vs Launch (with update)
echo • System tray integration: pystray with context menu
echo • Process management: Complete app lifecycle control
echo • File preservation: Critical launcher protection during updates
echo.
echo ✅ TESTING YOUR v8 ENHANCEMENTS:
echo.
echo 1. ENHANCED GUI LAUNCHER TEST:
echo    • Double-click Dojo.pyw → Bigger GUI opens (550x450)
echo    • Execute Portal → Direct app.pyw launch without version check
echo    • Launch Portal → Version check → Auto-update → System tray
echo    • Hide to Tray → System tray integration with context menu
echo    • Exit from tray → Kills ALL app.pyw processes
echo.
echo 2. PROCESS MANAGEMENT TEST:
echo    • Try launching app.pyw twice → Second attempt blocked
echo    • Check system tray → Right-click for menu options
echo    • Exit application → Verify all processes terminated
echo.
echo 3. REVIEW TAB ENHANCEMENT TEST:
echo    • Navigate to Review → Only commit_hash "Not Started"/"On Hold"
echo    • Change status → Engagement disappears from list
echo    • See "IR:{value}" formatting in bold context
echo.
echo 4. SMART UPDATE SYSTEM TEST:
echo    • Modify version.json → Launch Dojo.pyw
echo    • Download from new URL → File preservation → Auto cleanup
echo    • Verify Dojo.pyw preserved during update process
echo.
echo 🎯 LAUNCH OPTIONS:
echo.
echo OPTION A: Enhanced GUI Launcher (Recommended)
echo • Double-click Dojo.pyw
echo • Bigger interface with all enhanced features
echo • Execute button for direct launch
echo • Launch button for auto-update
echo • System tray integration
echo.
echo OPTION B: Direct Launch (Traditional)
echo • Double-click start.bat or run python app.pyw
echo • Direct portal access
echo.
echo 💼 ENTERPRISE v8 BENEFITS:
echo • Enhanced User Experience: Execute vs Launch options
echo • Process Protection: Prevents accidental double launches
echo • System Integration: Native tray support with proper cleanup
echo • Smart File Management: Preserves critical files during updates
echo • Focused Workflow: Review tab shows only relevant engagements
echo • Professional Interface: Bigger layout with all features visible
echo.
echo 🎊 PRODUCTION READY v8:
echo DefectDojo Clone v8 is the ultimate enhanced professional solution:
echo • Complete GUI enhancement with process management
echo • Advanced review workflow with commit_hash filtering
echo • Professional system integration with tray support
echo • Smart update system with file preservation
echo • Enterprise-grade process control and error handling
echo.
echo Starting DefectDojo Clone v8...
echo You can also launch the ENHANCED GUI by double-clicking Dojo.pyw
echo.
python app.pyw
pause
'''

project_files['start.bat'] = batch_content

shell_content = '''#!/bin/bash
echo "========================================================"
echo "DefectDojo Clone v8 - ULTIMATE ENHANCED GUI SYSTEM"
echo "========================================================"
echo ""
echo "🎉 NEW v8 BREAKTHROUGH ENHANCEMENTS:"
echo "• ENHANCED GUI: Execute button + bigger interface (550x450)"
echo "• PROCESS MANAGEMENT: Prevents double execution + kills all on exit"
echo "• SYSTEM TRAY: Full integration with restore and exit options"
echo "• SMART UPDATES: New URL + file preservation + auto cleanup"
echo "• REVIEW FILTER: Only commit_hash 'Not Started'/'On Hold' shown"
echo "• VERSION FROM JSON: Dynamic version reading from version.json"
echo ""
echo "🚀 ENHANCED GUI LAUNCHER FEATURES:"
echo "• Double-click Dojo.pyw opens BIGGER professional interface"
echo "• Execute Portal button: Direct app.pyw launch (no version check)"
echo "• Launch Portal button: Auto-update with version checking"
echo "• Hide to Tray button: System tray integration with menu"
echo "• Process detection: Prevents double browser execution"
echo "• Exit functionality: Kills ALL app.pyw processes properly"
echo ""
echo "🛡️ REVIEW TAB CRITICAL UPDATE:"
echo "• NEW LOGIC: Only shows if commit_hash = 'Not Started' or 'On Hold'"
echo "• IR display: 'IR:{value}' in bold near Lead Review Status"
echo "• Engagement PUT: Uses ALL 6 mandatory parameters"
echo "• Real-time removal: Engagements disappear when status changes"
echo ""
echo "🔧 ADVANCED SYSTEM FEATURES:"
echo "• New download URL: engagements/3/files/download/5/"
echo "• Smart file management: Preserves Dojo.pyw during updates"
echo "• Auto cleanup: Deletes zip files after extraction"
echo "• Process tracking: psutil integration for process management"
echo "• Enhanced error handling: Graceful recovery from all edge cases"
echo ""
echo "📋 TECHNICAL ARCHITECTURE ENHANCEMENTS:"
echo "• Bigger GUI window: 550x450 pixels for proper button layout"
echo "• Dual launch options: Execute (direct) vs Launch (with update)"
echo "• System tray integration: pystray with context menu"
echo "• Process management: Complete app lifecycle control"
echo "• File preservation: Critical launcher protection during updates"
echo ""
echo "✅ TESTING YOUR v8 ENHANCEMENTS:"
echo ""
echo "1. ENHANCED GUI LAUNCHER TEST:"
echo "   • Double-click Dojo.pyw → Bigger GUI opens (550x450)"
echo "   • Execute Portal → Direct app.pyw launch without version check"
echo "   • Launch Portal → Version check → Auto-update → System tray"
echo "   • Hide to Tray → System tray integration with context menu"
echo "   • Exit from tray → Kills ALL app.pyw processes"
echo ""
echo "2. PROCESS MANAGEMENT TEST:"
echo "   • Try launching app.pyw twice → Second attempt blocked"
echo "   • Check system tray → Right-click for menu options"
echo "   • Exit application → Verify all processes terminated"
echo ""
echo "3. REVIEW TAB ENHANCEMENT TEST:"
echo "   • Navigate to Review → Only commit_hash 'Not Started'/'On Hold'"
echo "   • Change status → Engagement disappears from list"
echo "   • See 'IR:{value}' formatting in bold context"
echo ""
echo "4. SMART UPDATE SYSTEM TEST:"
echo "   • Modify version.json → Launch Dojo.pyw"
echo "   • Download from new URL → File preservation → Auto cleanup"
echo "   • Verify Dojo.pyw preserved during update process"
echo ""
echo "🎯 LAUNCH OPTIONS:"
echo ""
echo "OPTION A: Enhanced GUI Launcher (Recommended)"
echo "• Double-click Dojo.pyw"
echo "• Bigger interface with all enhanced features"
echo "• Execute button for direct launch"
echo "• Launch button for auto-update"
echo "• System tray integration"
echo ""
echo "OPTION B: Direct Launch (Traditional)"
echo "• Double-click start.sh or run python3 app.pyw"
echo "• Direct portal access"
echo ""
echo "💼 ENTERPRISE v8 BENEFITS:"
echo "• Enhanced User Experience: Execute vs Launch options"
echo "• Process Protection: Prevents accidental double launches"
echo "• System Integration: Native tray support with proper cleanup"
echo "• Smart File Management: Preserves critical files during updates"
echo "• Focused Workflow: Review tab shows only relevant engagements"
echo "• Professional Interface: Bigger layout with all features visible"
echo ""
echo "🎊 PRODUCTION READY v8:"
echo "DefectDojo Clone v8 is the ultimate enhanced professional solution:"
echo "• Complete GUI enhancement with process management"
echo "• Advanced review workflow with commit_hash filtering"
echo "• Professional system integration with tray support"
echo "• Smart update system with file preservation"
echo "• Enterprise-grade process control and error handling"
echo ""
echo "Starting DefectDojo Clone v8..."
echo "You can also launch the ENHANCED GUI by double-clicking Dojo.pyw"
echo ""
python3 app.pyw
'''

project_files['start.sh'] = shell_content

print("Created enhanced batch and shell files for v8")