import os
import zipfile
import json
import re

# Initialize project structure
project_files = {}
templates = {}

# Create version.json for upgrade system
version_config = {
    "version": "1.0",
    "last_updated": "2025-10-06",
    "build": "enhanced-v8"
}

project_files['version.json'] = json.dumps(version_config, indent=2)

# Token configuration
token_config = {
    "api_token": "548afd6fab3bea9794a41b31da0e9404f733e222",
    "base_url": "https://demo.defectdojo.org"
}

project_files['token.json'] = json.dumps(token_config, indent=2)

print("Created initial configuration files for v8")