JiraScript.pyw GUI package
-------------------------
Files included:
- JiraScript.pyw   (double-click to run; opens GUI using the script's folder as CWD)
- jql.txt          (sample JQL; edit from the GUI and Save)

Notes:
- Double-click the .pyw file in its folder to run the GUI. The script sets working directory
  to the folder where the .pyw resides, so jql.txt will be read/written in that same folder.
- Requires Python 3.8+ and the packages: requests, pandas, openpyxl (for XLSX output).
  Install with: pip install requests pandas openpyxl
- If you want the GUI and export logic separated, extract export functions into a module.
